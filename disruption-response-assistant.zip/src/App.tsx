import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { DashboardMetrics } from './components/DashboardMetrics';
import { DisruptionInput } from './components/DisruptionInput';
import { AnalysisResults } from './components/AnalysisResults';
import { SupplyChainDatabaseView } from './components/SupplyChainDatabaseView';
import { RecentHistory } from './components/RecentHistory';
import { LocalSetupGuide } from './components/LocalSetupGuide';
import { AnalysisResult, SampleNotice } from './types';
import { SAMPLE_NOTICES, INITIAL_SUPPLIERS, INITIAL_SHIPMENTS, INITIAL_CUSTOMER_ORDERS } from './data/sampleDatabase';
import { AlertCircle, RefreshCw, Sparkles } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<'analyzer' | 'dashboard' | 'database' | 'local_setup'>('analyzer');
  const [noticeText, setNoticeText] = useState<string>(SAMPLE_NOTICES[0].content);
  const [selectedSampleId, setSelectedSampleId] = useState<string | null>(SAMPLE_NOTICES[0].id);
  const [analysisResult, setAnalysisResult] = useState<AnalysisResult | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [aiUsed, setAiUsed] = useState<boolean>(true);
  const [history, setHistory] = useState<AnalysisResult[]>([]);
  const [systemStatus, setSystemStatus] = useState({
    ready: true,
    geminiConfigured: true,
    suppliersCount: INITIAL_SUPPLIERS.length,
    shipmentsCount: INITIAL_SHIPMENTS.length,
    ordersCount: INITIAL_CUSTOMER_ORDERS.length,
  });

  // Fetch initial health and history
  useEffect(() => {
    fetch('/api/health')
      .then((r) => r.json())
      .then((data) => {
        if (data.status === 'ok') {
          setSystemStatus((prev) => ({
            ...prev,
            ready: true,
            geminiConfigured: data.geminiConfigured,
          }));
        }
      })
      .catch((err) => {
        console.warn('Backend health check error:', err);
      });

    fetch('/api/history')
      .then((r) => r.json())
      .then((data) => {
        if (data && Array.isArray(data.history)) {
          setHistory(data.history);
        }
      })
      .catch(() => {});
  }, []);

  const handleSelectSample = (sample: SampleNotice) => {
    setSelectedSampleId(sample.id);
    setNoticeText(sample.content);
    setError(null);
  };

  const handleClear = () => {
    setNoticeText('');
    setSelectedSampleId(null);
    setError(null);
  };

  const handleAnalyze = async (forceFallback = false) => {
    if (!noticeText.trim()) return;

    setIsLoading(true);
    setError(null);

    try {
      const response = await fetch('/api/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ noticeText, forceFallback }),
      });

      const data = await response.json();

      if (!response.ok || !data.success) {
        throw new Error(data.error || 'Disruption analysis request failed.');
      }

      setAnalysisResult(data.result);
      setAiUsed(data.aiUsed);

      // Refresh history list
      setHistory((prev) => [data.result, ...prev.filter((h) => h.id !== data.result.id)].slice(0, 15));
    } catch (err: any) {
      console.error('Analysis error:', err);
      setError(err?.message || 'An unexpected error occurred while communicating with the analysis engine.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleReset = () => {
    setAnalysisResult(null);
    setError(null);
  };

  const handleClearHistory = async () => {
    try {
      await fetch('/api/history', { method: 'DELETE' });
      setHistory([]);
    } catch (err) {
      console.warn('Failed to clear history:', err);
    }
  };

  const handleSelectHistoryItem = (item: AnalysisResult) => {
    setAnalysisResult(item);
    setNoticeText(item.noticeText);
    setActiveTab('analyzer');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Compute metrics from current analysis or aggregate history
  const activeReport = analysisResult?.executiveReport;
  const highRiskCount = activeReport?.riskCounts.high ?? 0;
  const mediumRiskCount = activeReport?.riskCounts.medium ?? 0;
  const lowRiskCount = activeReport?.riskCounts.low ?? 0;
  const affectedOrdersCount = analysisResult?.affectedOrders.length ?? 0;
  const affectedShipmentsCount = analysisResult?.affectedShipments.length ?? 0;

  return (
    <div className="min-h-screen bg-[#0b0f17] text-slate-100 flex flex-col">
      {/* Global Header */}
      <Header activeTab={activeTab} setActiveTab={setActiveTab} systemStatus={systemStatus} />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 md:py-8">
        {/* Top Operational Metrics Dashboard */}
        <DashboardMetrics
          affectedOrdersCount={affectedOrdersCount}
          highRiskCount={highRiskCount}
          mediumRiskCount={mediumRiskCount}
          lowRiskCount={lowRiskCount}
          affectedShipmentsCount={affectedShipmentsCount}
          totalMonitoredSuppliers={systemStatus.suppliersCount}
          isAnalyzed={!!analysisResult}
        />

        {/* Error Banner with Retry */}
        {error && (
          <div className="mb-6 p-4 rounded-xl bg-rose-950/40 border border-rose-800/80 text-rose-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-lg">
            <div className="flex items-start space-x-3">
              <AlertCircle className="w-5 h-5 text-rose-400 mt-0.5 flex-shrink-0" />
              <div>
                <span className="font-semibold text-sm text-white">Analysis Engine Error</span>
                <p className="text-xs text-rose-300/90 mt-0.5 leading-relaxed">{error}</p>
              </div>
            </div>

            <div className="flex items-center space-x-2 self-end sm:self-auto">
              <button
                id="retry-heuristic-btn"
                onClick={() => handleAnalyze(true)}
                className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition-colors"
              >
                Use Offline Heuristic
              </button>
              <button
                id="retry-analysis-btn"
                onClick={() => handleAnalyze(false)}
                className="px-3.5 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-white text-xs font-semibold flex items-center space-x-1.5 transition-colors"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Retry</span>
              </button>
            </div>
          </div>
        )}

        {/* Tab 1: Analyzer (Main View) */}
        {activeTab === 'analyzer' && (
          <div>
            <DisruptionInput
              noticeText={noticeText}
              setNoticeText={setNoticeText}
              onAnalyze={() => handleAnalyze(false)}
              isLoading={isLoading}
              selectedSampleId={selectedSampleId}
              onSelectSample={handleSelectSample}
              onClear={handleClear}
            />

            {analysisResult && (
              <AnalysisResults
                result={analysisResult}
                onReset={handleReset}
                aiUsed={aiUsed}
              />
            )}
          </div>
        )}

        {/* Tab 2: Dashboard Overview & History */}
        {activeTab === 'dashboard' && (
          <div className="space-y-6">
            <RecentHistory
              history={history}
              onSelectResult={handleSelectHistoryItem}
              onClearHistory={handleClearHistory}
            />

            {/* Quick launch card */}
            <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-6 flex flex-col sm:flex-row items-center justify-between gap-4">
              <div>
                <h3 className="text-base font-bold text-white">Ready to run a new scenario?</h3>
                <p className="text-xs text-slate-400 mt-1">
                  Evaluate supplier incident reports, force majeure notifications, or carrier weather bulletins.
                </p>
              </div>
              <button
                onClick={() => setActiveTab('analyzer')}
                className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold flex items-center space-x-2 transition-colors cursor-pointer"
              >
                <Sparkles className="w-4 h-4" />
                <span>Open Impact Analyzer</span>
              </button>
            </div>
          </div>
        )}

        {/* Tab 3: Supply Chain Database Explorer */}
        {activeTab === 'database' && <SupplyChainDatabaseView />}

        {/* Tab 4: Local Setup & Architecture */}
        {activeTab === 'local_setup' && <LocalSetupGuide />}
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-800/80 py-4 bg-[#0a0e17] text-center text-xs text-slate-500">
        <p>Disruption Response Assistant · Supply Chain Intelligence & Mitigation System</p>
      </footer>
    </div>
  );
}
