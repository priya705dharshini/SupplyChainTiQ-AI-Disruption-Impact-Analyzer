export type RiskLevel = 'HIGH' | 'MEDIUM' | 'LOW';

export interface Supplier {
  id: string;
  name: string;
  code: string;
  contactEmail: string;
  country: string;
  tier: 'Strategic' | 'Preferred' | 'Secondary';
  categories: string[];
  reliabilityScore: number; // e.g. 94%
}

export interface Shipment {
  id: string;
  supplierId: string;
  supplierName: string;
  trackingNumber: string;
  sku: string;
  productName: string;
  quantity: number;
  transitMode: 'Ocean' | 'Air' | 'Ground' | 'Express Freight';
  originPort: string;
  destinationWarehouse: string;
  departureDate: string; // YYYY-MM-DD
  originalEta: string; // YYYY-MM-DD
  status: 'In Transit' | 'Port Clearance' | 'Customs Hold' | 'Scheduled' | 'Delivered';
}

export interface WarehouseStock {
  sku: string;
  productName: string;
  category: string;
  onHand: number;
  reserved: number;
  available: number;
  safetyStockThreshold: number;
  warehouseLocation: string;
}

export interface CustomerOrder {
  id: string;
  customerName: string;
  customerTier: 'Tier 1 Strategic' | 'Enterprise' | 'Standard';
  sku: string;
  productName: string;
  orderedQuantity: number;
  orderDate: string;
  deadline: string; // YYYY-MM-DD customer delivery deadline / SLA
  allocatedShipmentId: string;
  status: 'Pending Receipt' | 'Processing' | 'At Risk' | 'Delayed' | 'Fulfilled';
  slaPenaltyPerDay?: number; // e.g. $500/day
}

export interface AiExtraction {
  supplierName: string;
  productCategory: string;
  disruptionType: string;
  delayDurationDays: number;
  importantDates: {
    incidentDate?: string;
    impactStart?: string;
    estimatedEnd?: string;
  };
  rawSummary: string;
  confidenceScore: number;
  isAmbiguous: boolean;
  notes?: string;
}

export interface AffectedOrder {
  orderId: string;
  customerName: string;
  customerTier: 'Tier 1 Strategic' | 'Enterprise' | 'Standard';
  sku: string;
  productName: string;
  orderedQuantity: number;
  allocatedShipmentId: string;
  originalDeliveryDate: string;
  newEstimatedDeliveryDate: string;
  deadline: string;
  delayDays: number;
  daysLate: number; // positive means past deadline
  riskLevel: RiskLevel;
  reason: string;
  responseOptions: [string, string];
  recommendedAction: string;
  stockBufferCovered?: boolean;
}

export interface ExecutiveReport {
  situationSummary: string;
  affectedSupplier: string;
  affectedShipments: string[]; // Shipment IDs
  affectedCustomerOrders: string[]; // Order IDs
  riskLevel: RiskLevel;
  riskCounts: {
    high: number;
    medium: number;
    low: number;
  };
  recommendedAction: string;
  mitigationStrategy: string;
  financialRiskEstimate?: string;
}

export interface AnalysisResult {
  id: string;
  timestamp: string;
  noticeText: string;
  extraction: AiExtraction;
  matchedSupplier: Supplier | null;
  affectedShipments: Shipment[];
  affectedOrders: AffectedOrder[];
  executiveReport: ExecutiveReport;
  hasImpact: boolean;
  noImpactReason?: string;
}

export interface SampleNotice {
  id: string;
  title: string;
  category: 'direct_impact' | 'ambiguous' | 'no_impact' | 'moderate_impact';
  badge: string;
  description: string;
  content: string;
}
