import {
  Supplier,
  Shipment,
  WarehouseStock,
  CustomerOrder,
  AiExtraction,
  AffectedOrder,
  ExecutiveReport,
  AnalysisResult,
  RiskLevel,
} from '../types';
import {
  INITIAL_SUPPLIERS,
  INITIAL_SHIPMENTS,
  INITIAL_WAREHOUSE_STOCK,
  INITIAL_CUSTOMER_ORDERS,
} from '../data/sampleDatabase';

// Date utility functions
export function addDays(dateStr: string, days: number): string {
  try {
    const d = new Date(dateStr);
    if (isNaN(d.getTime())) return dateStr;
    d.setDate(d.getDate() + days);
    return d.toISOString().split('T')[0];
  } catch {
    return dateStr;
  }
}

export function daysBetween(dateAStr: string, dateBStr: string): number {
  try {
    const a = new Date(dateAStr);
    const b = new Date(dateBStr);
    if (isNaN(a.getTime()) || isNaN(b.getTime())) return 0;
    const diffMs = b.getTime() - a.getTime();
    return Math.round(diffMs / (1000 * 60 * 60 * 24));
  } catch {
    return 0;
  }
}

export function formatDateDisplay(dateStr: string): string {
  if (!dateStr) return 'N/A';
  try {
    const d = new Date(dateStr);
    if (isNaN(d.getTime())) return dateStr;
    return d.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    });
  } catch {
    return dateStr;
  }
}

// Normalize supplier name for fuzzy matching
export function matchSupplier(
  extractedSupplier: string,
  suppliers: Supplier[] = INITIAL_SUPPLIERS
): Supplier | null {
  if (!extractedSupplier || extractedSupplier.trim() === '') return null;
  const cleanExtracted = extractedSupplier.toLowerCase().replace(/[^a-z0-9]/g, '');

  for (const s of suppliers) {
    const cleanSName = s.name.toLowerCase().replace(/[^a-z0-9]/g, '');
    const cleanCode = s.code.toLowerCase().replace(/[^a-z0-9]/g, '');

    if (
      cleanSName.includes(cleanExtracted) ||
      cleanExtracted.includes(cleanSName) ||
      cleanExtracted.includes(cleanCode) ||
      cleanCode.includes(cleanExtracted)
    ) {
      return s;
    }

    // Check individual significant tokens (e.g. "Apex", "Pacific", "Vanguard", "Dynalink", "Nordic")
    const sTokens = s.name.toLowerCase().split(/\s+/).filter((t) => t.length > 3);
    for (const token of sTokens) {
      if (cleanExtracted.includes(token)) {
        return s;
      }
    }
  }

  return null;
}

// Find shipments affected by supplier or SKU/product
export function findAffectedShipments(
  supplier: Supplier | null,
  extractedSkuOrProduct: string,
  shipments: Shipment[] = INITIAL_SHIPMENTS
): Shipment[] {
  if (!supplier && (!extractedSkuOrProduct || extractedSkuOrProduct.trim() === '')) {
    return [];
  }

  const cleanProduct = (extractedSkuOrProduct || '').toLowerCase();

  return shipments.filter((shp) => {
    // Match by supplier ID
    if (supplier && shp.supplierId === supplier.id) {
      return true;
    }
    // Or match by SKU / product keyword
    if (cleanProduct && (
      shp.sku.toLowerCase().includes(cleanProduct) ||
      cleanProduct.includes(shp.sku.toLowerCase()) ||
      shp.productName.toLowerCase().includes(cleanProduct)
    )) {
      return true;
    }
    return false;
  });
}

// Match customer orders affected by shipments
export function matchCustomerOrders(
  affectedShipments: Shipment[],
  customerOrders: CustomerOrder[] = INITIAL_CUSTOMER_ORDERS
): CustomerOrder[] {
  if (affectedShipments.length === 0) return [];
  const shipmentIds = new Set(affectedShipments.map((s) => s.id));
  const affectedSkus = new Set(affectedShipments.map((s) => s.sku.toUpperCase()));

  return customerOrders.filter((order) => {
    if (shipmentIds.has(order.allocatedShipmentId)) {
      return true;
    }
    if (affectedSkus.has(order.sku.toUpperCase())) {
      return true;
    }
    return false;
  });
}

// Run complete Risk Analysis on orders
export function analyzeOrderRisks(
  orders: CustomerOrder[],
  shipments: Shipment[],
  delayDays: number,
  warehouseStock: WarehouseStock[] = INITIAL_WAREHOUSE_STOCK
): AffectedOrder[] {
  return orders.map((order) => {
    // Find assigned shipment
    const shp = shipments.find((s) => s.id === order.allocatedShipmentId) || shipments.find((s) => s.sku === order.sku);
    const originalDeliveryDate = shp ? shp.originalEta : order.deadline;
    const newEstimatedDeliveryDate = addDays(originalDeliveryDate, delayDays);

    // Days late: difference between new delivery date and customer deadline
    // If newEstimatedDeliveryDate > order.deadline => daysLate > 0 (late!)
    const daysLate = daysBetween(order.deadline, newEstimatedDeliveryDate);

    let riskLevel: RiskLevel = 'LOW';
    let reason = '';

    if (daysLate > 0) {
      riskLevel = 'HIGH';
      reason = `Delivery delayed by ${delayDays} days, arriving ${daysLate} day${daysLate > 1 ? 's' : ''} past contractual deadline (${order.deadline}). SLA penalty risk.`;
    } else if (daysLate >= -3) {
      riskLevel = 'MEDIUM';
      reason = `New delivery date is within ${Math.abs(daysLate)} day${Math.abs(daysLate) === 1 ? '' : 's'} of deadline. Narrow safety buffer leaves zero tolerance for port or transit friction.`;
    } else {
      riskLevel = 'LOW';
      reason = `Adequate ${Math.abs(daysLate)}-day buffer remains prior to customer deadline (${order.deadline}). Standard monitoring sufficient.`;
    }

    // Check warehouse stock buffer
    const stock = warehouseStock.find((stk) => stk.sku === order.sku);
    const stockAvailable = stock ? stock.available : 0;
    const canBuffer = stockAvailable >= order.orderedQuantity;

    // Generate dynamic response options and recommended action
    let responseOptions: [string, string] = [
      `Option A: Expedite replacement allocation from regional buffer inventory or authorize emergency air-freight.`,
      `Option B: Proactively contact customer account team to renegotiate delivery window with SLA penalty waiver.`,
    ];
    let recommendedAction = '';

    if (riskLevel === 'HIGH') {
      if (canBuffer) {
        responseOptions = [
          `Option A: Immediately release ${order.orderedQuantity} units from ${stock?.warehouseLocation || 'central warehouse'} available reserve to satisfy full order without delay.`,
          `Option B: Dispatch available buffer of ${stockAvailable} units today and back-order remaining deficit via emergency air courier.`,
        ];
        recommendedAction = `Authorize instant release of ${order.orderedQuantity} reserve units from safety stock to prevent SLA breach of $${(order.slaPenaltyPerDay || 1000) * daysLate}.`;
      } else {
        responseOptions = [
          `Option A: Split shipment — dispatch ${stockAvailable > 0 ? stockAvailable : 'partial'} available units immediately, and re-route remaining balance via high-priority air freight.`,
          `Option B: Issue formal Disruption Notification to ${order.customerName}, offering expedited freight subsidy and a revised promised arrival date of ${newEstimatedDeliveryDate}.`,
        ];
        recommendedAction = `Engage ${order.customerName} procurement team within 4 hours to arrange split-delivery and waive daily penalty.`;
      }
    } else if (riskLevel === 'MEDIUM') {
      responseOptions = [
        `Option A: Pre-clear warehouse receiving dock and schedule priority cross-docking at destination hub upon vessel arrival.`,
        `Option B: Request carrier priority discharge at origin port to recover 2 days of terminal dwell time.`,
      ];
      recommendedAction = `Issue priority cross-docking order to logistics hub to compress receiving turnaround from 48h to 8h.`;
    } else {
      responseOptions = [
        `Option A: Maintain standard transit tracking with daily automated telemetry pings.`,
        `Option B: Tag order for standard exception monitoring without diverting costly air freight resources.`,
      ];
      recommendedAction = `Log standard ETA adjustment to ${newEstimatedDeliveryDate}. No emergency escalation required.`;
    }

    return {
      orderId: order.id,
      customerName: order.customerName,
      customerTier: order.customerTier,
      sku: order.sku,
      productName: order.productName,
      orderedQuantity: order.orderedQuantity,
      allocatedShipmentId: order.allocatedShipmentId,
      originalDeliveryDate,
      newEstimatedDeliveryDate,
      deadline: order.deadline,
      delayDays,
      daysLate,
      riskLevel,
      reason,
      responseOptions,
      recommendedAction,
      stockBufferCovered: canBuffer,
    };
  });
}

// Generate complete executive report
export function generateExecutiveReport(
  extraction: AiExtraction,
  supplier: Supplier | null,
  affectedShipments: Shipment[],
  affectedOrders: AffectedOrder[]
): ExecutiveReport {
  const highRisks = affectedOrders.filter((o) => o.riskLevel === 'HIGH').length;
  const mediumRisks = affectedOrders.filter((o) => o.riskLevel === 'MEDIUM').length;
  const lowRisks = affectedOrders.filter((o) => o.riskLevel === 'LOW').length;

  const overallRisk: RiskLevel =
    highRisks > 0 ? 'HIGH' : mediumRisks > 0 ? 'MEDIUM' : 'LOW';

  const shipmentIds = affectedShipments.map((s) => s.id);
  const orderIds = affectedOrders.map((o) => o.orderId);

  let situationSummary = '';
  let strategicRecommendation = '';
  let mitigationStrategy = '';

  if (affectedOrders.length === 0) {
    situationSummary = `The analyzed notice for ${extraction.supplierName || 'specified vendor'} reports a ${extraction.delayDurationDays}-day disruption (${extraction.disruptionType}), but no active shipments or open customer orders in our distribution network are compromised.`;
    strategicRecommendation = `No immediate operational intervention is required. Continue routine supplier monitoring.`;
    mitigationStrategy = `Maintain existing buffer stock and verify upcoming quarter purchase orders.`;
  } else {
    situationSummary = `Operational disruption reported at ${supplier?.name || extraction.supplierName} (${extraction.disruptionType}) introduces an estimated ${extraction.delayDurationDays}-day delay impacting ${shipmentIds.length} active shipment${shipmentIds.length > 1 ? 's' : ''} (${shipmentIds.join(', ')}) and exposing ${orderIds.length} downstream customer order${orderIds.length > 1 ? 's' : ''} (${orderIds.join(', ')}).`;

    if (highRisks > 0) {
      strategicRecommendation = `Immediately execute mitigation protocol for ${highRisks} critical order${highRisks > 1 ? 's' : ''} exceeding customer deadlines. Authorize safety stock allocation and priority cross-docking for high-value strategic accounts.`;
      mitigationStrategy = `1) Activate regional warehouse stock buffers where available.\n2) Issue priority carrier escalation for in-transit shipments.\n3) Proactively initiate SLA mitigation discussions with affected account managers.`;
    } else if (mediumRisks > 0) {
      strategicRecommendation = `Alert distribution center operations to implement hot-docking upon shipment arrival to safeguard tight customer delivery buffers.`;
      mitigationStrategy = `1) Pre-clear customs and terminal handling.\n2) Monitor vessel tracking daily for ETA volatility.\n3) Stage warehouse labor for same-day dispatch.`;
    } else {
      strategicRecommendation = `Existing delivery schedules absorb the ${extraction.delayDurationDays}-day variance safely. Standard tracking is sufficient.`;
      mitigationStrategy = `Continue automated telemetry monitoring and update customer portals with adjusted arrival dates.`;
    }
  }

  return {
    situationSummary,
    affectedSupplier: supplier?.name || extraction.supplierName || 'Unknown Supplier',
    affectedShipments: shipmentIds,
    affectedCustomerOrders: orderIds,
    riskLevel: overallRisk,
    riskCounts: {
      high: highRisks,
      medium: mediumRisks,
      low: lowRisks,
    },
    recommendedAction: strategicRecommendation,
    mitigationStrategy,
  };
}

// Fallback extraction parser when AI is unavailable or offline
export function heuristicExtract(noticeText: string): AiExtraction {
  const lower = noticeText.toLowerCase();

  // Find supplier
  let matchedSupplierName = '';
  for (const s of INITIAL_SUPPLIERS) {
    if (lower.includes(s.name.toLowerCase()) || lower.includes(s.code.toLowerCase())) {
      matchedSupplierName = s.name;
      break;
    }
  }
  if (!matchedSupplierName) {
    if (lower.includes('apex')) matchedSupplierName = 'Apex Microelectronics';
    else if (lower.includes('pacific precision') || lower.includes('pacific optics')) matchedSupplierName = 'Pacific Precision Optics';
    else if (lower.includes('vanguard')) matchedSupplierName = 'Vanguard Power Systems';
    else if (lower.includes('dynalink')) matchedSupplierName = 'Shenzhen Dynalink Electronics';
    else if (lower.includes('nordic timber')) matchedSupplierName = 'Nordic Timber AB';
    else if (lower.includes('delta wire')) matchedSupplierName = 'Delta Wire & Harness Co.';
  }

  // Find delay days
  let delayDays = 7;
  const dayMatch = lower.match(/(\d{1,2})\s*(?:calendar\s*)?(?:business\s*)?days?/i);
  if (dayMatch) {
    delayDays = parseInt(dayMatch[1], 10);
  } else if (lower.includes('two weeks') || lower.includes('2 weeks')) {
    delayDays = 14;
  } else if (lower.includes('one week') || lower.includes('1 week')) {
    delayDays = 7;
  } else if (lower.includes('3 to 6 days') || lower.includes('3-6 days')) {
    delayDays = 5;
  }

  // Disruption type
  let disruptionType = 'Supply Chain Delay';
  if (lower.includes('breakdown') || lower.includes('failure') || lower.includes('equipment')) {
    disruptionType = 'Equipment Failure & Fab Interruption';
  } else if (lower.includes('typhoon') || lower.includes('weather') || lower.includes('storm')) {
    disruptionType = 'Severe Weather & Maritime Port Closure';
  } else if (lower.includes('fire') || lower.includes('transformer')) {
    disruptionType = 'Facility Fire & Power Disruption';
  } else if (lower.includes('brownout') || lower.includes('power grid') || lower.includes('outage')) {
    disruptionType = 'Electrical Grid Instability';
  } else if (lower.includes('port congestion') || lower.includes('customs')) {
    disruptionType = 'Port Congestion & Customs Clearance Delay';
  }

  // Products
  let productCategory = 'Industrial Components';
  if (lower.includes('mcu') || lower.includes('microcontroller') || lower.includes('semiconductor')) {
    productCategory = 'Microcontrollers / Semiconductors';
  } else if (lower.includes('sensor') || lower.includes('lens') || lower.includes('optical')) {
    productCategory = 'Optical Sensors & Inspection Lenses';
  } else if (lower.includes('power') || lower.includes('converter') || lower.includes('battery')) {
    productCategory = 'Power Conversion Modules';
  } else if (lower.includes('pallet') || lower.includes('lumber') || lower.includes('timber')) {
    productCategory = 'Packaging & Wood Pallets';
  }

  const isAmbiguous =
    lower.includes('advisory') ||
    lower.includes('unconfirmed') ||
    lower.includes('potential') ||
    lower.includes('projected 3 to 6');

  return {
    supplierName: matchedSupplierName || 'Unidentified Supplier',
    productCategory,
    disruptionType,
    delayDurationDays: delayDays,
    importantDates: {
      incidentDate: '2026-09-04',
      impactStart: '2026-09-05',
      estimatedEnd: addDays('2026-09-05', delayDays),
    },
    rawSummary: `Parsed disruption for ${matchedSupplierName || 'vendor'} indicating ${delayDays}-day delay due to ${disruptionType}.`,
    confidenceScore: matchedSupplierName ? 0.92 : 0.65,
    isAmbiguous,
    notes: isAmbiguous ? 'Disruption notice contains advisory/unconfirmed terms.' : undefined,
  };
}
