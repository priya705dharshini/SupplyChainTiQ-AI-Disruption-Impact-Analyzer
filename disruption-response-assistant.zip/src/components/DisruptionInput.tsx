import React from 'react';
import { Sparkles, Send, RotateCcw, FileText, HelpCircle, CheckCircle2, AlertTriangle } from 'lucide-react';
import { SAMPLE_NOTICES } from '../data/sampleDatabase';
import { SampleNotice } from '../types';

interface DisruptionInputProps {
  noticeText: string;
  setNoticeText: (text: string) => void;
  onAnalyze: () => void;
  isLoading: boolean;
  selectedSampleId: string | null;
  onSelectSample: (sample: SampleNotice) => void;
  onClear: () => void;
}

export const DisruptionInput: React.FC<DisruptionInputProps> = ({
  noticeText,
  setNoticeText,
  onAnalyze,
  isLoading,
  selectedSampleId,
  onSelectSample,
  onClear,
}) => {
  return (
    <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 md:p-6 mb-8 shadow-xl">
      {/* Title & Description */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-4">
        <div>
          <h2 className="text-lg font-bold text-white flex items-center space-x-2">
            <FileText className="w-5 h-5 text-indigo-400" />
            <span>Disruption Notice Input</span>
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Paste supplier emails, shipping notices, port advisories, or incident reports for AI impact assessment.
          </p>
        </div>

        {noticeText && (
          <button
            onClick={onClear}
            disabled={isLoading}
            className="self-start sm:self-auto text-xs text-slate-400 hover:text-slate-200 flex items-center space-x-1 px-2.5 py-1 rounded-md border border-slate-800 hover:bg-slate-800/60 transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Clear Text</span>
          </button>
        )}
      </div>

      {/* Sample Notices Selector */}
      <div className="mb-4">
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs font-semibold uppercase tracking-wider text-slate-400 flex items-center">
            <Sparkles className="w-3.5 h-3.5 mr-1 text-indigo-400" /> Quick-Test Sample Notices:
          </span>
          <span className="text-[11px] text-slate-400">Click a scenario to load</span>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5">
          {SAMPLE_NOTICES.map((sample) => {
            const isSelected = selectedSampleId === sample.id;
            let badgeBg = 'bg-slate-800 text-slate-300';
            if (sample.category === 'direct_impact') badgeBg = 'bg-rose-950/80 text-rose-300 border border-rose-800/50';
            else if (sample.category === 'ambiguous') badgeBg = 'bg-amber-950/80 text-amber-300 border border-amber-800/50';
            else if (sample.category === 'no_impact') badgeBg = 'bg-emerald-950/80 text-emerald-300 border border-emerald-800/50';
            else if (sample.category === 'moderate_impact') badgeBg = 'bg-indigo-950/80 text-indigo-300 border border-indigo-800/50';

            return (
              <button
                key={sample.id}
                id={`sample-btn-${sample.id}`}
                onClick={() => onSelectSample(sample)}
                type="button"
                className={`text-left p-3 rounded-xl border transition-all relative overflow-hidden ${
                  isSelected
                    ? 'bg-indigo-950/40 border-indigo-500 shadow-md shadow-indigo-950/30'
                    : 'bg-slate-950/50 border-slate-800/80 hover:bg-slate-800/40 hover:border-slate-700'
                }`}
              >
                <div className="flex items-center justify-between mb-1.5">
                  <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${badgeBg}`}>
                    {sample.badge}
                  </span>
                  {isSelected && <span className="w-2 h-2 rounded-full bg-indigo-400 animate-pulse"></span>}
                </div>
                <div className="text-xs font-semibold text-slate-200 line-clamp-1">
                  {sample.title}
                </div>
                <p className="text-[11px] text-slate-400 mt-1 line-clamp-2 leading-relaxed">
                  {sample.description}
                </p>
              </button>
            );
          })}
        </div>
      </div>

      {/* Large Text Area */}
      <div className="relative mb-4">
        <textarea
          id="disruption-textarea"
          value={noticeText}
          onChange={(e) => setNoticeText(e.target.value)}
          placeholder="Paste supplier notice, delay advisory, or incident report here (e.g. 'Apex Microelectronics Taichung cleanroom failure causing 14-day delay on MCU-X200...')"
          rows={7}
          disabled={isLoading}
          className="w-full bg-slate-950/80 border border-slate-800 rounded-xl p-4 text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-500/50 focus:border-indigo-500 font-mono transition-all resize-y"
        />
        <div className="absolute bottom-3 right-3 text-[11px] text-slate-400 bg-slate-900/90 px-2 py-0.5 rounded border border-slate-800">
          {noticeText.length} characters
        </div>
      </div>

      {/* Action Row */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="flex items-center space-x-2 text-xs text-slate-400">
          <HelpCircle className="w-4 h-4 text-slate-400 flex-shrink-0" />
          <span>
            Gemini extracts supplier, delay days & SKUs, then auto-matches open purchase orders & SLAs.
          </span>
        </div>

        <button
          id="analyze-impact-btn"
          onClick={onAnalyze}
          disabled={isLoading || !noticeText.trim()}
          className={`w-full sm:w-auto px-6 py-3 rounded-xl font-semibold text-sm flex items-center justify-center space-x-2 transition-all shadow-lg ${
            isLoading || !noticeText.trim()
              ? 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700/50'
              : 'bg-gradient-to-r from-indigo-600 via-indigo-500 to-blue-600 text-white hover:from-indigo-500 hover:to-blue-500 shadow-indigo-600/25 cursor-pointer active:scale-95'
          }`}
        >
          {isLoading ? (
            <>
              <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
              <span>Analyzing Disruption...</span>
            </>
          ) : (
            <>
              <Sparkles className="w-4 h-4" />
              <span>Analyze Impact</span>
            </>
          )}
        </button>
      </div>
    </div>
  );
};
