import React from 'react';
import { AlertTriangle, AlertCircle, CheckCircle2, PackageX, Truck, ShieldCheck } from 'lucide-react';

interface DashboardMetricsProps {
  affectedOrdersCount: number;
  highRiskCount: number;
  mediumRiskCount: number;
  lowRiskCount: number;
  affectedShipmentsCount: number;
  totalMonitoredSuppliers: number;
  activeDisruptionName?: string;
  isAnalyzed: boolean;
}

export const DashboardMetrics: React.FC<DashboardMetricsProps> = ({
  affectedOrdersCount,
  highRiskCount,
  mediumRiskCount,
  lowRiskCount,
  affectedShipmentsCount,
  totalMonitoredSuppliers,
  activeDisruptionName,
  isAnalyzed,
}) => {
  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4 mb-6">
      {/* High Risk Orders */}
      <div
        id="metric-card-high-risk"
        className={`p-4 rounded-xl border transition-all ${
          highRiskCount > 0
            ? 'bg-rose-950/30 border-rose-800/60 shadow-lg shadow-rose-950/20'
            : 'bg-slate-900/60 border-slate-800/80'
        }`}
      >
        <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
          <span className="font-medium text-rose-300">High Risk</span>
          <AlertTriangle className="w-4 h-4 text-rose-400" />
        </div>
        <div className="flex items-baseline space-x-2">
          <span className={`text-2xl font-bold font-mono ${highRiskCount > 0 ? 'text-rose-400' : 'text-slate-200'}`}>
            {highRiskCount}
          </span>
          <span className="text-xs text-slate-400">orders</span>
        </div>
        <p className="text-[11px] text-slate-400 mt-1">Past customer SLA deadline</p>
      </div>

      {/* Medium Risk Orders */}
      <div
        id="metric-card-medium-risk"
        className={`p-4 rounded-xl border transition-all ${
          mediumRiskCount > 0
            ? 'bg-amber-950/30 border-amber-800/60 shadow-lg shadow-amber-950/20'
            : 'bg-slate-900/60 border-slate-800/80'
        }`}
      >
        <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
          <span className="font-medium text-amber-300">Medium Risk</span>
          <AlertCircle className="w-4 h-4 text-amber-400" />
        </div>
        <div className="flex items-baseline space-x-2">
          <span className={`text-2xl font-bold font-mono ${mediumRiskCount > 0 ? 'text-amber-400' : 'text-slate-200'}`}>
            {mediumRiskCount}
          </span>
          <span className="text-xs text-slate-400">orders</span>
        </div>
        <p className="text-[11px] text-slate-400 mt-1">Narrow deadline buffer (≤3d)</p>
      </div>

      {/* Low Risk Orders */}
      <div
        id="metric-card-low-risk"
        className={`p-4 rounded-xl border transition-all ${
          lowRiskCount > 0
            ? 'bg-emerald-950/30 border-emerald-800/60 shadow-lg shadow-emerald-950/20'
            : 'bg-slate-900/60 border-slate-800/80'
        }`}
      >
        <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
          <span className="font-medium text-emerald-300">Low Risk</span>
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
        </div>
        <div className="flex items-baseline space-x-2">
          <span className={`text-2xl font-bold font-mono ${lowRiskCount > 0 ? 'text-emerald-400' : 'text-slate-200'}`}>
            {lowRiskCount}
          </span>
          <span className="text-xs text-slate-400">orders</span>
        </div>
        <p className="text-[11px] text-slate-400 mt-1">Adequate buffer margin</p>
      </div>

      {/* Total Affected Orders */}
      <div
        id="metric-card-total-orders"
        className="p-4 rounded-xl bg-slate-900/60 border border-slate-800/80"
      >
        <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
          <span className="font-medium text-indigo-300">Affected Orders</span>
          <PackageX className="w-4 h-4 text-indigo-400" />
        </div>
        <div className="flex items-baseline space-x-2">
          <span className="text-2xl font-bold font-mono text-indigo-300">
            {affectedOrdersCount}
          </span>
          <span className="text-xs text-slate-400">total</span>
        </div>
        <p className="text-[11px] text-slate-400 mt-1">Active customer allocations</p>
      </div>

      {/* Delayed Shipments */}
      <div
        id="metric-card-shipments"
        className="p-4 rounded-xl bg-slate-900/60 border border-slate-800/80"
      >
        <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
          <span className="font-medium text-cyan-300">Delayed Shipments</span>
          <Truck className="w-4 h-4 text-cyan-400" />
        </div>
        <div className="flex items-baseline space-x-2">
          <span className="text-2xl font-bold font-mono text-cyan-300">
            {affectedShipmentsCount}
          </span>
          <span className="text-xs text-slate-400">vessels/air</span>
        </div>
        <p className="text-[11px] text-slate-400 mt-1">Inbound transit line items</p>
      </div>

      {/* System Status / Network */}
      <div
        id="metric-card-status"
        className="p-4 rounded-xl bg-slate-900/60 border border-slate-800/80"
      >
        <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
          <span className="font-medium text-slate-300">Vendor Network</span>
          <ShieldCheck className="w-4 h-4 text-emerald-400" />
        </div>
        <div className="flex items-baseline space-x-2">
          <span className="text-2xl font-bold font-mono text-white">
            {totalMonitoredSuppliers}
          </span>
          <span className="text-xs text-slate-400">suppliers</span>
        </div>
        <p className="text-[11px] text-emerald-400 mt-1 flex items-center">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 mr-1.5 animate-ping"></span>
          Telemetry Active
        </p>
      </div>
    </div>
  );
};
