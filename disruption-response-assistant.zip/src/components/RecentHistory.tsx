import React from 'react';
import { History, Trash2, ArrowRight, AlertTriangle, AlertCircle, CheckCircle2, FileText } from 'lucide-react';
import { AnalysisResult } from '../types';
import { formatDateDisplay } from '../utils/analysisEngine';

interface RecentHistoryProps {
  history: AnalysisResult[];
  onSelectResult: (result: AnalysisResult) => void;
  onClearHistory: () => void;
}

export const RecentHistory: React.FC<RecentHistoryProps> = ({
  history,
  onSelectResult,
  onClearHistory,
}) => {
  if (history.length === 0) {
    return (
      <div className="bg-slate-900/60 border border-slate-800/80 rounded-2xl p-6 text-center text-slate-400">
        <History className="w-8 h-8 mx-auto text-slate-600 mb-2" />
        <p className="text-sm font-semibold text-slate-300">No Disruption Analyses Logged Yet</p>
        <p className="text-xs text-slate-500 mt-1">
          Paste a disruption notice in the Analyzer tab or select a sample scenario to run an impact evaluation.
        </p>
      </div>
    );
  }

  return (
    <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 md:p-6 mb-8 shadow-xl">
      <div className="flex items-center justify-between mb-4 border-b border-slate-800/80 pb-3">
        <div className="flex items-center space-x-2">
          <History className="w-5 h-5 text-indigo-400" />
          <h3 className="text-base font-bold text-white tracking-tight">
            Recent Disruption Analyses ({history.length})
          </h3>
        </div>

        <button
          onClick={onClearHistory}
          className="text-xs text-slate-400 hover:text-rose-400 flex items-center space-x-1 px-2.5 py-1 rounded-md border border-slate-800 hover:border-rose-900/60 transition-colors"
        >
          <Trash2 className="w-3.5 h-3.5" />
          <span>Clear History</span>
        </button>
      </div>

      <div className="space-y-3">
        {history.map((item) => {
          const isHigh = item.executiveReport.riskLevel === 'HIGH';
          const isMed = item.executiveReport.riskLevel === 'MEDIUM';

          return (
            <div
              key={item.id}
              onClick={() => onSelectResult(item)}
              className="p-4 rounded-xl bg-slate-950/60 border border-slate-800/80 hover:bg-slate-800/40 hover:border-indigo-500/50 cursor-pointer transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3 group"
            >
              <div className="flex items-start space-x-3">
                <div
                  className={`w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0 text-xs font-bold font-mono ${
                    isHigh
                      ? 'bg-rose-950 text-rose-300 border border-rose-800'
                      : isMed
                      ? 'bg-amber-950 text-amber-300 border border-amber-800'
                      : 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                  }`}
                >
                  {isHigh ? (
                    <AlertTriangle className="w-4 h-4" />
                  ) : isMed ? (
                    <AlertCircle className="w-4 h-4" />
                  ) : (
                    <CheckCircle2 className="w-4 h-4" />
                  )}
                </div>

                <div>
                  <div className="flex items-center space-x-2">
                    <span className="text-sm font-bold text-white group-hover:text-indigo-300 transition-colors">
                      {item.extraction.supplierName || 'Unidentified Supplier'}
                    </span>
                    <span className="text-xs text-slate-400">·</span>
                    <span className="text-xs text-slate-300 font-mono">
                      +{item.extraction.delayDurationDays} days
                    </span>
                    {!item.hasImpact && (
                      <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-950 text-emerald-300 border border-emerald-800">
                        No Impact
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-slate-400 mt-1 line-clamp-1">
                    {item.extraction.disruptionType} — {item.extraction.rawSummary}
                  </p>
                  <div className="flex items-center space-x-3 mt-1.5 text-[11px] text-slate-500 font-mono">
                    <span>{new Date(item.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                    <span>·</span>
                    <span>{item.affectedShipments.length} shipments affected</span>
                    <span>·</span>
                    <span>{item.affectedOrders.length} customer orders</span>
                  </div>
                </div>
              </div>

              <div className="flex items-center space-x-2 self-end sm:self-center">
                <span className="text-xs text-indigo-400 group-hover:translate-x-0.5 transition-transform flex items-center space-x-1">
                  <span>View Details</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
