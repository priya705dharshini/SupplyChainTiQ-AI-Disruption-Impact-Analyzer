import React from 'react';
import { ShieldAlert, Activity, Database, Terminal, Layers, Sparkles } from 'lucide-react';

interface HeaderProps {
  activeTab: 'analyzer' | 'dashboard' | 'database' | 'local_setup';
  setActiveTab: (tab: 'analyzer' | 'dashboard' | 'database' | 'local_setup') => void;
  systemStatus: {
    ready: boolean;
    geminiConfigured: boolean;
    suppliersCount: number;
    shipmentsCount: number;
    ordersCount: number;
  };
}

export const Header: React.FC<HeaderProps> = ({ activeTab, setActiveTab, systemStatus }) => {
  return (
    <header className="border-b border-slate-800 bg-[#0f172a]/95 backdrop-blur-md sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo & App Name */}
          <div className="flex items-center space-x-3 cursor-pointer" onClick={() => setActiveTab('analyzer')}>
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-500 via-blue-600 to-cyan-500 p-0.5 shadow-lg shadow-indigo-500/20 flex items-center justify-center">
              <div className="w-full h-full bg-[#0b0f17] rounded-[10px] flex items-center justify-center">
                <ShieldAlert className="w-5 h-5 text-indigo-400" />
              </div>
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="text-lg font-bold tracking-tight text-white">
                  Disruption Response Assistant
                </span>
                <span className="hidden sm:inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-indigo-950 text-indigo-300 border border-indigo-800/60">
                  <Sparkles className="w-3 h-3 mr-1 text-indigo-400" /> AI Supply Chain
                </span>
              </div>
              <p className="text-xs text-slate-400 hidden sm:block">
                Distributor Impact Analyzer & Mitigation Engine
              </p>
            </div>
          </div>

          {/* Navigation Tabs */}
          <nav className="hidden md:flex items-center space-x-1">
            <button
              id="nav-tab-analyzer"
              onClick={() => setActiveTab('analyzer')}
              className={`px-3.5 py-2 rounded-lg text-sm font-medium transition-colors flex items-center space-x-2 ${
                activeTab === 'analyzer'
                  ? 'bg-indigo-600/20 text-indigo-400 border border-indigo-500/30'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
              }`}
            >
              <Activity className="w-4 h-4" />
              <span>Impact Analyzer</span>
            </button>
            <button
              id="nav-tab-dashboard"
              onClick={() => setActiveTab('dashboard')}
              className={`px-3.5 py-2 rounded-lg text-sm font-medium transition-colors flex items-center space-x-2 ${
                activeTab === 'dashboard'
                  ? 'bg-indigo-600/20 text-indigo-400 border border-indigo-500/30'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
              }`}
            >
              <Layers className="w-4 h-4" />
              <span>Overview & History</span>
            </button>
            <button
              id="nav-tab-database"
              onClick={() => setActiveTab('database')}
              className={`px-3.5 py-2 rounded-lg text-sm font-medium transition-colors flex items-center space-x-2 ${
                activeTab === 'database'
                  ? 'bg-indigo-600/20 text-indigo-400 border border-indigo-500/30'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
              }`}
            >
              <Database className="w-4 h-4" />
              <span>Supply Chain DB</span>
            </button>
            <button
              id="nav-tab-setup"
              onClick={() => setActiveTab('local_setup')}
              className={`px-3.5 py-2 rounded-lg text-sm font-medium transition-colors flex items-center space-x-2 ${
                activeTab === 'local_setup'
                  ? 'bg-indigo-600/20 text-indigo-400 border border-indigo-500/30'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
              }`}
            >
              <Terminal className="w-4 h-4" />
              <span>Flask & Local Run</span>
            </button>
          </nav>

          {/* System Status Pill */}
          <div className="flex items-center space-x-2">
            <div className="flex items-center space-x-1.5 px-2.5 py-1 rounded-full bg-slate-900/90 border border-slate-800 text-xs text-slate-300">
              <span className={`w-2 h-2 rounded-full ${systemStatus.ready ? 'bg-emerald-400 animate-pulse' : 'bg-amber-400'}`}></span>
              <span className="hidden sm:inline font-mono">AI Engine:</span>
              <span className="text-emerald-400 font-semibold">Ready</span>
            </div>
          </div>
        </div>

        {/* Mobile Navigation Row */}
        <div className="md:hidden flex items-center justify-around py-2 border-t border-slate-800/60 text-xs">
          <button
            onClick={() => setActiveTab('analyzer')}
            className={`px-2.5 py-1.5 rounded-md font-medium ${
              activeTab === 'analyzer' ? 'text-indigo-400 bg-indigo-950/60' : 'text-slate-400'
            }`}
          >
            Analyzer
          </button>
          <button
            onClick={() => setActiveTab('dashboard')}
            className={`px-2.5 py-1.5 rounded-md font-medium ${
              activeTab === 'dashboard' ? 'text-indigo-400 bg-indigo-950/60' : 'text-slate-400'
            }`}
          >
            Overview
          </button>
          <button
            onClick={() => setActiveTab('database')}
            className={`px-2.5 py-1.5 rounded-md font-medium ${
              activeTab === 'database' ? 'text-indigo-400 bg-indigo-950/60' : 'text-slate-400'
            }`}
          >
            Database
          </button>
          <button
            onClick={() => setActiveTab('local_setup')}
            className={`px-2.5 py-1.5 rounded-md font-medium ${
              activeTab === 'local_setup' ? 'text-indigo-400 bg-indigo-950/60' : 'text-slate-400'
            }`}
          >
            Local Setup
          </button>
        </div>
      </div>
    </header>
  );
};
