import React, { useState } from 'react';
import { Terminal, Copy, Check, Server, Code, FileText, Cpu, CheckCircle2 } from 'lucide-react';

export const LocalSetupGuide: React.FC = () => {
  const [copiedSection, setCopiedSection] = useState<string | null>(null);

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedSection(id);
    setTimeout(() => setCopiedSection(null), 2000);
  };

  const flaskSetupCmds = `# 1. Clone or navigate to the repository
cd disruption-response-assistant

# 2. Enter the backend directory and set up Python venv
cd backend_flask
python -m venv venv

# Activate venv:
# macOS / Linux:
source venv/bin/activate
# Windows:
# venv\\Scripts\\activate

# 3. Install Python dependencies
pip install -r requirements.txt

# 4. Set your Google Gemini API key
export GEMINI_API_KEY="your-gemini-api-key-here"
# On Windows PowerShell: $env:GEMINI_API_KEY="your-gemini-api-key-here"

# 5. Start the Flask Backend Server (runs on port 5000)
python app.py`;

  const nodeSetupCmds = `# 1. Install Node.js dependencies in the root directory
npm install

# 2. Configure your environment variable in .env
echo "GEMINI_API_KEY=your-gemini-api-key-here" > .env

# 3. Run the fullstack dev server (Express + Vite on port 3000)
npm run dev

# 4. For production build:
npm run build
npm start`;

  return (
    <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 md:p-8 mb-8 shadow-xl">
      <div className="flex items-center space-x-3 mb-6 border-b border-slate-800/80 pb-4">
        <div className="w-10 h-10 rounded-xl bg-indigo-950 flex items-center justify-center text-indigo-400 border border-indigo-800/60">
          <Terminal className="w-5 h-5" />
        </div>
        <div>
          <h2 className="text-lg font-bold text-white tracking-tight">
            Local Deployment & Project Architecture Guide
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Step-by-step instructions for running Disruption Response Assistant locally with Python Flask or Node/Express.
          </p>
        </div>
      </div>

      {/* Architecture Overview */}
      <div className="mb-8">
        <h3 className="text-sm font-bold uppercase tracking-wider text-indigo-300 mb-3 flex items-center space-x-2">
          <Cpu className="w-4 h-4" />
          <span>System Architecture & Pipeline Flow</span>
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-3 text-xs">
          <div className="bg-slate-950/70 p-4 rounded-xl border border-slate-800/80">
            <span className="w-6 h-6 rounded-full bg-indigo-950 text-indigo-300 border border-indigo-800 flex items-center justify-center font-bold font-mono mb-2">
              1
            </span>
            <span className="font-bold text-white block mb-1">Disruption Intake</span>
            <p className="text-slate-400 text-[11px] leading-relaxed">
              Unstructured supplier emails, shipping notices, or incident reports are input into the system.
            </p>
          </div>

          <div className="bg-slate-950/70 p-4 rounded-xl border border-slate-800/80">
            <span className="w-6 h-6 rounded-full bg-indigo-950 text-indigo-300 border border-indigo-800 flex items-center justify-center font-bold font-mono mb-2">
              2
            </span>
            <span className="font-bold text-white block mb-1">Gemini AI Extraction</span>
            <p className="text-slate-400 text-[11px] leading-relaxed">
              Gemini 3.8 Flash extracts supplier name, product line, disruption type, delay duration, and key dates.
            </p>
          </div>

          <div className="bg-slate-950/70 p-4 rounded-xl border border-slate-800/80">
            <span className="w-6 h-6 rounded-full bg-indigo-950 text-indigo-300 border border-indigo-800 flex items-center justify-center font-bold font-mono mb-2">
              3
            </span>
            <span className="font-bold text-white block mb-1">Supply Chain Matching</span>
            <p className="text-slate-400 text-[11px] leading-relaxed">
              Deterministic cross-referencing against suppliers, inbound shipments, warehouse stock, and open customer orders.
            </p>
          </div>

          <div className="bg-slate-950/70 p-4 rounded-xl border border-slate-800/80">
            <span className="w-6 h-6 rounded-full bg-indigo-950 text-indigo-300 border border-indigo-800 flex items-center justify-center font-bold font-mono mb-2">
              4
            </span>
            <span className="font-bold text-white block mb-1">Risk & Action Engine</span>
            <p className="text-slate-400 text-[11px] leading-relaxed">
              Calculates revised delivery dates, categorizes HIGH/MED/LOW risk vs SLA deadlines, and formulates response options.
            </p>
          </div>
        </div>
      </div>

      {/* Project Structure Breakdown */}
      <div className="mb-8">
        <h3 className="text-sm font-bold uppercase tracking-wider text-indigo-300 mb-3 flex items-center space-x-2">
          <Code className="w-4 h-4" />
          <span>Project Directory Structure</span>
        </h3>

        <div className="bg-slate-950/80 rounded-xl p-4 border border-slate-800/80 text-xs font-mono text-slate-300 leading-relaxed overflow-x-auto">
          <pre>{`├── backend_flask/              # Python Flask backend option
│   ├── app.py                  # Flask REST API (Gemini extraction, matching, risk engine)
│   ├── sample_data.json        # Suppliers, Shipments, Warehouse Stock, Orders DB
│   ├── requirements.txt        # Flask, flask-cors, google-genai, python-dotenv
│   └── README.md               # Dedicated Python run instructions
│
├── server.ts                   # Full-Stack Node/Express server (powers live AI Studio preview)
│                               # Integrates @google/genai SDK, API routes, and Vite middleware
│
├── src/
│   ├── components/
│   │   ├── Header.tsx                 # Top navigation and system health status
│   │   ├── DashboardMetrics.tsx       # KPI cards (High/Med/Low risk, impacted counts)
│   │   ├── DisruptionInput.tsx        # Large textarea, quick sample notice cards
│   │   ├── AnalysisResults.tsx        # Extraction details, affected shipments, order cards
│   │   ├── NoImpactView.tsx           # Clear "No Impact Found" state display
│   │   ├── SupplyChainDatabaseView.tsx # Master database explorer (Suppliers, Stock, Orders)
│   │   ├── RecentHistory.tsx          # Past disruption analyses audit log
│   │   └── LocalSetupGuide.tsx        # This local running & deployment reference
│   │
│   ├── data/
│   │   └── sampleDatabase.ts   # Realistic electronics/distributor test dataset & notices
│   ├── utils/
│   │   └── analysisEngine.ts   # Date arithmetic, supplier matching, risk scoring algorithms
│   ├── types.ts                # Strict TypeScript interfaces
│   ├── App.tsx                 # Root coordinator component
│   └── main.tsx                # React DOM entrypoint
│
├── metadata.json               # Platform configuration & server-side Gemini declaration
└── package.json                # React 19, Vite 6, Tailwind CSS v4, Express, @google/genai`}</pre>
        </div>
      </div>

      {/* Option 1: Python Flask Backend */}
      <div className="mb-8">
        <div className="flex items-center justify-between mb-2">
          <h3 className="text-sm font-bold uppercase tracking-wider text-white flex items-center space-x-2">
            <Server className="w-4 h-4 text-emerald-400" />
            <span>Option 1: Run with Python Flask Backend</span>
          </h3>
          <button
            onClick={() => copyToClipboard(flaskSetupCmds, 'flask')}
            className="text-xs text-slate-400 hover:text-slate-200 flex items-center space-x-1 px-2 py-1 rounded bg-slate-800 border border-slate-700 transition-colors"
          >
            {copiedSection === 'flask' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copiedSection === 'flask' ? 'Copied' : 'Copy Commands'}</span>
          </button>
        </div>
        <p className="text-xs text-slate-400 mb-3">
          Ideal if your team prefers Python for data science and logistics pipelines. Uses the official <code className="text-indigo-300">google-genai</code> Python library.
        </p>
        <div className="bg-slate-950/80 rounded-xl p-4 border border-slate-800/80 text-xs font-mono text-emerald-400 leading-relaxed overflow-x-auto">
          <pre>{flaskSetupCmds}</pre>
        </div>
      </div>

      {/* Option 2: Full-Stack Node/Express */}
      <div>
        <div className="flex items-center justify-between mb-2">
          <h3 className="text-sm font-bold uppercase tracking-wider text-white flex items-center space-x-2">
            <Server className="w-4 h-4 text-cyan-400" />
            <span>Option 2: Run Full-Stack with Node.js & Express</span>
          </h3>
          <button
            onClick={() => copyToClipboard(nodeSetupCmds, 'node')}
            className="text-xs text-slate-400 hover:text-slate-200 flex items-center space-x-1 px-2 py-1 rounded bg-slate-800 border border-slate-700 transition-colors"
          >
            {copiedSection === 'node' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copiedSection === 'node' ? 'Copied' : 'Copy Commands'}</span>
          </button>
        </div>
        <p className="text-xs text-slate-400 mb-3">
          Single process running React + Vite + Express API on port 3000 using <code className="text-indigo-300">server.ts</code> and TypeScript.
        </p>
        <div className="bg-slate-950/80 rounded-xl p-4 border border-slate-800/80 text-xs font-mono text-cyan-300 leading-relaxed overflow-x-auto">
          <pre>{nodeSetupCmds}</pre>
        </div>
      </div>
    </div>
  );
};
