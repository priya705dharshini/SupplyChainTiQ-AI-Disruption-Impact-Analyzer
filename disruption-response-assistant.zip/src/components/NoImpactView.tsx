import React from 'react';
import { CheckCircle2, ShieldCheck, ArrowRight, RefreshCw, AlertCircle } from 'lucide-react';
import { AiExtraction, Supplier } from '../types';

interface NoImpactViewProps {
  extraction: AiExtraction;
  matchedSupplier: Supplier | null;
  noImpactReason?: string;
  onReset: () => void;
}

export const NoImpactView: React.FC<NoImpactViewProps> = ({
  extraction,
  matchedSupplier,
  noImpactReason,
  onReset,
}) => {
  return (
    <div
      id="no-impact-banner"
      className="bg-slate-900/90 border border-emerald-800/60 rounded-2xl p-6 md:p-8 mb-8 shadow-xl shadow-emerald-950/10 relative overflow-hidden"
    >
      {/* Background subtle glow */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-emerald-500/5 rounded-full blur-3xl pointer-events-none -mr-20 -mt-20"></div>

      <div className="flex flex-col md:flex-row items-start md:items-center gap-6 relative z-10">
        <div className="w-14 h-14 rounded-2xl bg-emerald-950/80 border border-emerald-700/60 flex items-center justify-center flex-shrink-0 text-emerald-400 shadow-inner">
          <ShieldCheck className="w-8 h-8" />
        </div>

        <div className="flex-1">
          <div className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-950 text-emerald-300 border border-emerald-800/80 mb-2">
            <CheckCircle2 className="w-3.5 h-3.5 mr-1 text-emerald-400" /> Operational Status: Clear
          </div>

          <h3 className="text-xl font-bold text-white tracking-tight">
            No Impact Found on Active Customer Orders
          </h3>

          <p className="text-sm text-slate-300 mt-1 leading-relaxed max-w-3xl">
            {noImpactReason ||
              `The disruption reported for ${extraction.supplierName} (${extraction.disruptionType}, ${extraction.delayDurationDays} days) has been verified. No inbound transit shipments or scheduled customer deliveries in our database are compromised.`}
          </p>

          {/* Audit Details */}
          <div className="mt-4 grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="bg-slate-950/60 border border-slate-800/80 rounded-lg p-3">
              <span className="text-[11px] text-slate-400 uppercase tracking-wider block">Identified Entity</span>
              <span className="text-xs font-semibold text-white mt-0.5 block truncate">
                {extraction.supplierName || 'None'}
              </span>
              <span className="text-[10px] text-slate-400">
                {matchedSupplier ? `Matched: ${matchedSupplier.code}` : 'External / Not in Core Network'}
              </span>
            </div>

            <div className="bg-slate-950/60 border border-slate-800/80 rounded-lg p-3">
              <span className="text-[11px] text-slate-400 uppercase tracking-wider block">Disruption Severity</span>
              <span className="text-xs font-semibold text-slate-300 mt-0.5 block">
                {extraction.delayDurationDays} Days Reported
              </span>
              <span className="text-[10px] text-emerald-400">0 Open Shipments Affected</span>
            </div>

            <div className="bg-slate-950/60 border border-slate-800/80 rounded-lg p-3">
              <span className="text-[11px] text-slate-400 uppercase tracking-wider block">Customer Delivery Exposure</span>
              <span className="text-xs font-semibold text-emerald-400 mt-0.5 block">
                0 At-Risk Orders
              </span>
              <span className="text-[10px] text-slate-400">SLA Deadlines Protected</span>
            </div>
          </div>
        </div>

        <div className="self-stretch sm:self-auto flex sm:flex-col justify-end gap-2">
          <button
            onClick={onReset}
            className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center justify-center space-x-1.5 transition-colors border border-slate-700"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>New Analysis</span>
          </button>
        </div>
      </div>
    </div>
  );
};
