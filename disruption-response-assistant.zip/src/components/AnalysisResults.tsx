import React, { useState } from 'react';
import {
  AlertTriangle,
  AlertCircle,
  CheckCircle2,
  Calendar,
  Building2,
  Truck,
  Package,
  Layers,
  Sparkles,
  ClipboardCopy,
  Check,
  HelpCircle,
  ExternalLink,
  ChevronRight,
  TrendingUp,
  ShieldAlert,
  ArrowRight,
} from 'lucide-react';
import { AnalysisResult, AffectedOrder, RiskLevel } from '../types';
import { formatDateDisplay } from '../utils/analysisEngine';
import { NoImpactView } from './NoImpactView';

interface AnalysisResultsProps {
  result: AnalysisResult;
  onReset: () => void;
  aiUsed: boolean;
  geminiError?: string | null;
}

export const AnalysisResults: React.FC<AnalysisResultsProps> = ({
  result,
  onReset,
  aiUsed,
  geminiError,
}) => {
  const [copied, setCopied] = useState(false);
  const [selectedOrderTab, setSelectedOrderTab] = useState<'all' | 'high' | 'medium' | 'low'>('all');

  const {
    extraction,
    matchedSupplier,
    affectedShipments,
    affectedOrders,
    executiveReport,
    hasImpact,
    noImpactReason,
  } = result;

  // If no impact found, render the NoImpactView
  if (!hasImpact) {
    return (
      <NoImpactView
        extraction={extraction}
        matchedSupplier={matchedSupplier}
        noImpactReason={noImpactReason}
        onReset={onReset}
      />
    );
  }

  // Filter orders by tab
  const filteredOrders = affectedOrders.filter((order) => {
    if (selectedOrderTab === 'high') return order.riskLevel === 'HIGH';
    if (selectedOrderTab === 'medium') return order.riskLevel === 'MEDIUM';
    if (selectedOrderTab === 'low') return order.riskLevel === 'LOW';
    return true;
  });

  const copyReportToClipboard = () => {
    const reportText = `DISRUPTION RESPONSE REPORT
-----------------------------------------
Supplier: ${matchedSupplier?.name || extraction.supplierName}
Disruption: ${extraction.disruptionType} (${extraction.delayDurationDays} days delay)
Risk Level: ${executiveReport.riskLevel}

AFFECTED SHIPMENTS:
${affectedShipments.map((s) => `- ${s.id} (${s.sku}, Qty: ${s.quantity}) | ETA: ${s.originalEta} -> Delayed ETA: ${s.destinationWarehouse}`).join('\n')}

AFFECTED CUSTOMER ORDERS:
${affectedOrders
  .map(
    (o) =>
      `- [${o.riskLevel}] Order: ${o.orderId} | Customer: ${o.customerName} (${o.customerTier}) | SKU: ${o.sku} (Qty: ${o.orderedQuantity})
   Shipment: ${o.allocatedShipmentId} | Deadline: ${o.deadline} | New ETA: ${o.newEstimatedDeliveryDate} (${o.daysLate > 0 ? `+${o.daysLate}d LATE` : `${Math.abs(o.daysLate)}d buffer`})
   Recommended Action: ${o.recommendedAction}`
  )
  .join('\n\n')}

EXECUTIVE SUMMARY:
${executiveReport.situationSummary}

PRIMARY RECOMMENDED ACTION:
${executiveReport.recommendedAction}
`;
    navigator.clipboard.writeText(reportText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <div className="space-y-6 mb-12">
      {/* Top Banner: AI Status and Copy Action */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-900/90 border border-slate-800 p-4 rounded-xl">
        <div className="flex items-center space-x-2.5">
          <div className="w-8 h-8 rounded-lg bg-indigo-950 flex items-center justify-center text-indigo-400 border border-indigo-800/60">
            <Sparkles className="w-4 h-4" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <span className="text-sm font-bold text-white">Impact Analysis Completed</span>
              <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-indigo-950 text-indigo-300 border border-indigo-800">
                {aiUsed ? 'Gemini 3.8 Flash AI' : 'Heuristic Engine'}
              </span>
              {extraction.isAmbiguous && (
                <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-amber-950 text-amber-300 border border-amber-800">
                  Ambiguous Notice Flagged
                </span>
              )}
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              Identified {affectedShipments.length} shipment{affectedShipments.length > 1 ? 's' : ''} & {affectedOrders.length} customer order{affectedOrders.length > 1 ? 's' : ''} impacted
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-2">
          <button
            onClick={copyReportToClipboard}
            className="px-3.5 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center space-x-1.5 transition-colors border border-slate-700"
          >
            {copied ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-400" />
                <span className="text-emerald-300">Report Copied!</span>
              </>
            ) : (
              <>
                <ClipboardCopy className="w-3.5 h-3.5" />
                <span>Copy Executive Report</span>
              </>
            )}
          </button>

          <button
            onClick={onReset}
            className="px-3.5 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold transition-colors"
          >
            New Notice
          </button>
        </div>
      </div>

      {/* SECTION 1: AI Extraction Summary Card */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 md:p-6 shadow-xl">
        <div className="flex items-center justify-between mb-4 border-b border-slate-800/80 pb-3">
          <div className="flex items-center space-x-2">
            <Building2 className="w-5 h-5 text-indigo-400" />
            <h3 className="text-base font-bold text-white tracking-tight">
              1. Extracted Disruption Parameters
            </h3>
          </div>
          <div className="text-xs text-slate-400 flex items-center space-x-1">
            <span>Confidence:</span>
            <span className="font-mono text-emerald-400 font-semibold">
              {Math.round(extraction.confidenceScore * 100)}%
            </span>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-slate-950/60 p-3.5 rounded-xl border border-slate-800/80">
            <span className="text-[11px] text-slate-400 uppercase tracking-wider block">Supplier Name</span>
            <span className="text-sm font-bold text-white mt-1 block truncate">
              {extraction.supplierName}
            </span>
            <span className="text-[11px] text-indigo-400 mt-0.5 block">
              {matchedSupplier ? `Verified (${matchedSupplier.country})` : 'Unverified Supplier'}
            </span>
          </div>

          <div className="bg-slate-950/60 p-3.5 rounded-xl border border-slate-800/80">
            <span className="text-[11px] text-slate-400 uppercase tracking-wider block">Disruption Type</span>
            <span className="text-sm font-bold text-rose-300 mt-1 block truncate">
              {extraction.disruptionType}
            </span>
            <span className="text-[11px] text-slate-400 mt-0.5 block truncate">
              {extraction.productCategory}
            </span>
          </div>

          <div className="bg-slate-950/60 p-3.5 rounded-xl border border-slate-800/80">
            <span className="text-[11px] text-slate-400 uppercase tracking-wider block">Delay Duration</span>
            <div className="flex items-baseline space-x-1 mt-1">
              <span className="text-xl font-bold font-mono text-amber-400">
                +{extraction.delayDurationDays}
              </span>
              <span className="text-xs text-slate-300">calendar days</span>
            </div>
            <span className="text-[11px] text-slate-400 mt-0.5 block">
              Calculated across all affected legs
            </span>
          </div>

          <div className="bg-slate-950/60 p-3.5 rounded-xl border border-slate-800/80">
            <span className="text-[11px] text-slate-400 uppercase tracking-wider block">Impact Window</span>
            <span className="text-xs font-semibold text-slate-200 mt-1 block font-mono">
              {extraction.importantDates.impactStart || 'Immediate'} →{' '}
              {extraction.importantDates.estimatedEnd || 'TBD'}
            </span>
            <span className="text-[11px] text-slate-400 mt-0.5 block">
              {extraction.isAmbiguous ? 'Subject to port clearance' : 'Definitive downtime'}
            </span>
          </div>
        </div>

        {/* Raw Extraction Note */}
        <div className="mt-4 p-3 rounded-xl bg-slate-950/40 border border-slate-800/60 text-xs text-slate-300 flex items-start space-x-2">
          <HelpCircle className="w-4 h-4 text-indigo-400 mt-0.5 flex-shrink-0" />
          <p className="leading-relaxed">
            <span className="font-semibold text-slate-200">AI Context: </span>
            {extraction.rawSummary}
          </p>
        </div>
      </div>

      {/* SECTION 2: AI Executive Report & Strategic Recommendation */}
      <div className="bg-gradient-to-br from-slate-900 via-slate-900 to-indigo-950/30 border border-indigo-800/40 rounded-2xl p-5 md:p-6 shadow-xl relative overflow-hidden">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-4 border-b border-slate-800/80 pb-3">
          <div className="flex items-center space-x-2">
            <ShieldAlert className="w-5 h-5 text-indigo-400" />
            <h3 className="text-base font-bold text-white tracking-tight">
              2. Executive Response & Mitigation Report
            </h3>
          </div>

          {/* Risk Level Badge */}
          <div className="flex items-center space-x-2">
            <span className="text-xs text-slate-400">Severity Assessment:</span>
            <span
              className={`px-3 py-1 rounded-full text-xs font-bold font-mono tracking-wider flex items-center space-x-1.5 ${
                executiveReport.riskLevel === 'HIGH'
                  ? 'bg-rose-950 text-rose-300 border border-rose-700 animate-pulse'
                  : executiveReport.riskLevel === 'MEDIUM'
                  ? 'bg-amber-950 text-amber-300 border border-amber-700'
                  : 'bg-emerald-950 text-emerald-300 border border-emerald-700'
              }`}
            >
              {executiveReport.riskLevel === 'HIGH' && <AlertTriangle className="w-3.5 h-3.5" />}
              {executiveReport.riskLevel === 'MEDIUM' && <AlertCircle className="w-3.5 h-3.5" />}
              {executiveReport.riskLevel === 'LOW' && <CheckCircle2 className="w-3.5 h-3.5" />}
              <span>{executiveReport.riskLevel} RISK</span>
            </span>
          </div>
        </div>

        {/* Situation Summary */}
        <div className="mb-5">
          <span className="text-xs font-semibold uppercase tracking-wider text-slate-400 block mb-1.5">
            Situation Summary:
          </span>
          <p className="text-sm text-slate-200 leading-relaxed bg-slate-950/60 p-4 rounded-xl border border-slate-800/80">
            {executiveReport.situationSummary}
          </p>
        </div>

        {/* Primary Recommended Action Callout */}
        <div className="mb-5 bg-gradient-to-r from-indigo-950/70 via-indigo-900/40 to-slate-950/80 border-l-4 border-l-indigo-500 border border-indigo-800/60 p-4 rounded-xl shadow-lg">
          <div className="flex items-start space-x-3">
            <div className="w-8 h-8 rounded-lg bg-indigo-600/30 text-indigo-300 flex items-center justify-center flex-shrink-0 mt-0.5">
              <TrendingUp className="w-4 h-4" />
            </div>
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-indigo-300 block">
                Primary Recommended Action
              </span>
              <p className="text-sm font-semibold text-white mt-1 leading-relaxed">
                {executiveReport.recommendedAction}
              </p>
            </div>
          </div>
        </div>

        {/* 3-Step Mitigation Plan */}
        <div>
          <span className="text-xs font-semibold uppercase tracking-wider text-slate-400 block mb-2">
            Strategic Action Protocol:
          </span>
          <div className="bg-slate-950/60 rounded-xl p-4 border border-slate-800/80 text-xs text-slate-300 leading-relaxed whitespace-pre-line font-mono">
            {executiveReport.mitigationStrategy}
          </div>
        </div>
      </div>

      {/* SECTION 3: Affected Shipments Table */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 md:p-6 shadow-xl">
        <div className="flex items-center justify-between mb-4 border-b border-slate-800/80 pb-3">
          <div className="flex items-center space-x-2">
            <Truck className="w-5 h-5 text-cyan-400" />
            <h3 className="text-base font-bold text-white tracking-tight">
              3. Affected Inbound Shipments ({affectedShipments.length})
            </h3>
          </div>
          <span className="text-xs text-slate-400">Supplier: {matchedSupplier?.name || extraction.supplierName}</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-950/80 text-slate-400 text-[11px] uppercase tracking-wider border-b border-slate-800">
              <tr>
                <th className="py-3 px-4">Shipment ID</th>
                <th className="py-3 px-4">Product / SKU</th>
                <th className="py-3 px-4">Quantity</th>
                <th className="py-3 px-4">Transit Mode</th>
                <th className="py-3 px-4">Origin & Route</th>
                <th className="py-3 px-4">Original ETA</th>
                <th className="py-3 px-4">New Delayed ETA</th>
                <th className="py-3 px-4">Variance</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {affectedShipments.map((shp) => {
                const delayedEta = formatDateDisplay(
                  new Date(new Date(shp.originalEta).getTime() + extraction.delayDurationDays * 86400000)
                    .toISOString()
                    .split('T')[0]
                );

                return (
                  <tr key={shp.id} className="hover:bg-slate-800/30 transition-colors">
                    <td className="py-3 px-4 font-mono font-bold text-indigo-300">
                      {shp.id}
                      <span className="block text-[10px] text-slate-500 font-normal">{shp.trackingNumber}</span>
                    </td>
                    <td className="py-3 px-4">
                      <span className="font-semibold text-white block">{shp.sku}</span>
                      <span className="text-[11px] text-slate-400 block truncate max-w-xs">{shp.productName}</span>
                    </td>
                    <td className="py-3 px-4 font-mono text-slate-200">
                      {shp.quantity.toLocaleString()} units
                    </td>
                    <td className="py-3 px-4">
                      <span className="px-2 py-0.5 rounded text-[10px] font-medium bg-slate-800 text-slate-300 border border-slate-700">
                        {shp.transitMode}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-[11px] text-slate-400">
                      <span className="block text-slate-300">{shp.originPort}</span>
                      <span className="block text-[10px] text-slate-500">→ {shp.destinationWarehouse}</span>
                    </td>
                    <td className="py-3 px-4 font-mono text-slate-300">
                      {formatDateDisplay(shp.originalEta)}
                    </td>
                    <td className="py-3 px-4 font-mono font-bold text-amber-300">
                      {delayedEta}
                    </td>
                    <td className="py-3 px-4 font-mono text-rose-400 font-semibold">
                      +{extraction.delayDurationDays}d
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* SECTION 4: Affected Customer Orders & Actionable Response Options */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 md:p-6 shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4 border-b border-slate-800/80 pb-3">
          <div className="flex items-center space-x-2">
            <Package className="w-5 h-5 text-indigo-400" />
            <h3 className="text-base font-bold text-white tracking-tight">
              4. Affected Customer Orders & Response Actions ({affectedOrders.length})
            </h3>
          </div>

          {/* Filter Pills */}
          <div className="flex items-center space-x-1.5 self-start sm:self-auto bg-slate-950/80 p-1 rounded-lg border border-slate-800 text-xs">
            <button
              onClick={() => setSelectedOrderTab('all')}
              className={`px-2.5 py-1 rounded-md font-medium transition-colors ${
                selectedOrderTab === 'all' ? 'bg-slate-800 text-white' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              All ({affectedOrders.length})
            </button>
            <button
              onClick={() => setSelectedOrderTab('high')}
              className={`px-2.5 py-1 rounded-md font-medium transition-colors flex items-center space-x-1 ${
                selectedOrderTab === 'high' ? 'bg-rose-950 text-rose-300 border border-rose-800' : 'text-rose-400 hover:text-rose-300'
              }`}
            >
              <span>High Risk ({executiveReport.riskCounts.high})</span>
            </button>
            <button
              onClick={() => setSelectedOrderTab('medium')}
              className={`px-2.5 py-1 rounded-md font-medium transition-colors flex items-center space-x-1 ${
                selectedOrderTab === 'medium' ? 'bg-amber-950 text-amber-300 border border-amber-800' : 'text-amber-400 hover:text-amber-300'
              }`}
            >
              <span>Medium Risk ({executiveReport.riskCounts.medium})</span>
            </button>
            <button
              onClick={() => setSelectedOrderTab('low')}
              className={`px-2.5 py-1 rounded-md font-medium transition-colors flex items-center space-x-1 ${
                selectedOrderTab === 'low' ? 'bg-emerald-950 text-emerald-300 border border-emerald-800' : 'text-emerald-400 hover:text-emerald-300'
              }`}
            >
              <span>Low Risk ({executiveReport.riskCounts.low})</span>
            </button>
          </div>
        </div>

        {/* Detailed Order Action Cards */}
        <div className="space-y-4">
          {filteredOrders.map((order) => {
            const isHigh = order.riskLevel === 'HIGH';
            const isMed = order.riskLevel === 'MEDIUM';

            let cardBorder = 'border-slate-800/80 bg-slate-950/50';
            let riskBadgeBg = 'bg-emerald-950 text-emerald-300 border-emerald-800';

            if (isHigh) {
              cardBorder = 'border-rose-800/60 bg-rose-950/10 shadow-lg shadow-rose-950/10';
              riskBadgeBg = 'bg-rose-950 text-rose-300 border-rose-800 font-bold';
            } else if (isMed) {
              cardBorder = 'border-amber-800/60 bg-amber-950/10';
              riskBadgeBg = 'bg-amber-950 text-amber-300 border-amber-800 font-bold';
            }

            return (
              <div
                key={order.orderId}
                id={`order-card-${order.orderId}`}
                className={`p-5 rounded-xl border transition-all ${cardBorder}`}
              >
                {/* Header row */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-3 pb-3 border-b border-slate-800/60">
                  <div className="flex items-center space-x-3">
                    <span className="text-base font-bold font-mono text-indigo-300">
                      {order.orderId}
                    </span>
                    <span className="text-sm font-semibold text-white">
                      {order.customerName}
                    </span>
                    <span className="px-2 py-0.5 rounded text-[10px] font-medium bg-slate-800 text-slate-300 border border-slate-700">
                      {order.customerTier}
                    </span>
                  </div>

                  <div className="flex items-center space-x-2">
                    <span className={`px-2.5 py-1 rounded-full text-xs font-mono border ${riskBadgeBg}`}>
                      {order.riskLevel} RISK
                    </span>
                  </div>
                </div>

                {/* Grid info: Product, Quantities, Dates & SLA Gap */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-4 text-xs">
                  <div className="bg-slate-900/80 p-2.5 rounded-lg border border-slate-800/60">
                    <span className="text-[10px] text-slate-400 uppercase tracking-wider block">Product & SKU</span>
                    <span className="font-semibold text-slate-200 mt-0.5 block truncate">{order.sku}</span>
                    <span className="text-[11px] text-slate-400 truncate block">{order.productName}</span>
                  </div>

                  <div className="bg-slate-900/80 p-2.5 rounded-lg border border-slate-800/60">
                    <span className="text-[10px] text-slate-400 uppercase tracking-wider block">Quantity & Shipment</span>
                    <span className="font-semibold text-white mt-0.5 block font-mono">
                      {order.orderedQuantity.toLocaleString()} units
                    </span>
                    <span className="text-[11px] text-indigo-400 block font-mono">Shipment: {order.allocatedShipmentId}</span>
                  </div>

                  <div className="bg-slate-900/80 p-2.5 rounded-lg border border-slate-800/60">
                    <span className="text-[10px] text-slate-400 uppercase tracking-wider block">Customer SLA Deadline</span>
                    <span className="font-semibold text-slate-200 mt-0.5 block font-mono">
                      {formatDateDisplay(order.deadline)}
                    </span>
                    <span className="text-[11px] text-slate-400 block">
                      Original: {formatDateDisplay(order.originalDeliveryDate)}
                    </span>
                  </div>

                  <div className="bg-slate-900/80 p-2.5 rounded-lg border border-slate-800/60">
                    <span className="text-[10px] text-slate-400 uppercase tracking-wider block">New Estimated Arrival</span>
                    <span className={`font-bold mt-0.5 block font-mono ${isHigh ? 'text-rose-400' : isMed ? 'text-amber-300' : 'text-emerald-400'}`}>
                      {formatDateDisplay(order.newEstimatedDeliveryDate)}
                    </span>
                    <span className={`text-[11px] font-semibold block ${isHigh ? 'text-rose-400' : isMed ? 'text-amber-400' : 'text-emerald-400'}`}>
                      {order.daysLate > 0 ? `+${order.daysLate} days past deadline` : `${Math.abs(order.daysLate)} days safety buffer`}
                    </span>
                  </div>
                </div>

                {/* Reason Explanation */}
                <p className="text-xs text-slate-300 mb-3 bg-slate-900/50 p-2.5 rounded-lg border border-slate-800/40">
                  <span className="font-semibold text-slate-400">Risk Assessment: </span>
                  {order.reason}
                </p>

                {/* Two Response Options */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5 mb-3">
                  <div className="p-3 rounded-lg bg-slate-900/70 border border-slate-800 text-xs">
                    <span className="font-bold text-indigo-300 text-[11px] uppercase tracking-wider block mb-1">
                      Response Option 1
                    </span>
                    <p className="text-slate-300 leading-relaxed">{order.responseOptions[0]}</p>
                  </div>
                  <div className="p-3 rounded-lg bg-slate-900/70 border border-slate-800 text-xs">
                    <span className="font-bold text-cyan-300 text-[11px] uppercase tracking-wider block mb-1">
                      Response Option 2
                    </span>
                    <p className="text-slate-300 leading-relaxed">{order.responseOptions[1]}</p>
                  </div>
                </div>

                {/* Single Recommended Action */}
                <div className="p-3 rounded-lg bg-indigo-950/40 border border-indigo-800/60 flex items-start space-x-2.5 text-xs">
                  <TrendingUp className="w-4 h-4 text-indigo-400 mt-0.5 flex-shrink-0" />
                  <div>
                    <span className="font-bold text-indigo-300 uppercase tracking-wider text-[10px] block">
                      Recommended Action for {order.orderId}
                    </span>
                    <p className="text-white font-medium mt-0.5 leading-relaxed">
                      {order.recommendedAction}
                    </p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
