import React, { useState } from 'react';
import { Database, Search, Building2, Truck, Package, Layers, ExternalLink } from 'lucide-react';
import {
  INITIAL_SUPPLIERS,
  INITIAL_SHIPMENTS,
  INITIAL_WAREHOUSE_STOCK,
  INITIAL_CUSTOMER_ORDERS,
} from '../data/sampleDatabase';
import { formatDateDisplay } from '../utils/analysisEngine';

export const SupplyChainDatabaseView: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'suppliers' | 'shipments' | 'inventory' | 'orders'>('suppliers');
  const [searchTerm, setSearchTerm] = useState('');

  const filteredSuppliers = INITIAL_SUPPLIERS.filter(
    (s) =>
      s.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.country.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.categories.some((c) => c.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  const filteredShipments = INITIAL_SHIPMENTS.filter(
    (s) =>
      s.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.supplierName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.sku.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.productName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.destinationWarehouse.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const filteredStock = INITIAL_WAREHOUSE_STOCK.filter(
    (w) =>
      w.sku.toLowerCase().includes(searchTerm.toLowerCase()) ||
      w.productName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      w.category.toLowerCase().includes(searchTerm.toLowerCase()) ||
      w.warehouseLocation.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const filteredOrders = INITIAL_CUSTOMER_ORDERS.filter(
    (o) =>
      o.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      o.customerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      o.sku.toLowerCase().includes(searchTerm.toLowerCase()) ||
      o.allocatedShipmentId.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 md:p-6 mb-8 shadow-xl">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-6 border-b border-slate-800/80 pb-4">
        <div>
          <h2 className="text-lg font-bold text-white flex items-center space-x-2">
            <Database className="w-5 h-5 text-indigo-400" />
            <span>Master Supply Chain Database</span>
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Active distributor inventory, carrier tracking manifests, and downstream contractual customer commitments.
          </p>
        </div>

        {/* Search Bar */}
        <div className="relative w-full sm:w-64">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search SKUs, vendors, orders..."
            className="w-full bg-slate-950/80 border border-slate-800 rounded-xl pl-9 pr-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-indigo-500 font-mono"
          />
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center space-x-1.5 mb-5 border-b border-slate-800 pb-2 overflow-x-auto text-xs">
        <button
          onClick={() => setActiveTab('suppliers')}
          className={`px-3.5 py-2 rounded-lg font-medium transition-colors flex items-center space-x-2 ${
            activeTab === 'suppliers'
              ? 'bg-indigo-600/20 text-indigo-400 border border-indigo-500/40'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
          }`}
        >
          <Building2 className="w-3.5 h-3.5" />
          <span>Suppliers ({INITIAL_SUPPLIERS.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('shipments')}
          className={`px-3.5 py-2 rounded-lg font-medium transition-colors flex items-center space-x-2 ${
            activeTab === 'shipments'
              ? 'bg-indigo-600/20 text-indigo-400 border border-indigo-500/40'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
          }`}
        >
          <Truck className="w-3.5 h-3.5" />
          <span>Inbound Shipments ({INITIAL_SHIPMENTS.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('inventory')}
          className={`px-3.5 py-2 rounded-lg font-medium transition-colors flex items-center space-x-2 ${
            activeTab === 'inventory'
              ? 'bg-indigo-600/20 text-indigo-400 border border-indigo-500/40'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
          }`}
        >
          <Layers className="w-3.5 h-3.5" />
          <span>Warehouse Stock ({INITIAL_WAREHOUSE_STOCK.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('orders')}
          className={`px-3.5 py-2 rounded-lg font-medium transition-colors flex items-center space-x-2 ${
            activeTab === 'orders'
              ? 'bg-indigo-600/20 text-indigo-400 border border-indigo-500/40'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
          }`}
        >
          <Package className="w-3.5 h-3.5" />
          <span>Customer Orders ({INITIAL_CUSTOMER_ORDERS.length})</span>
        </button>
      </div>

      {/* Tab Contents */}

      {/* 1. Suppliers Table */}
      {activeTab === 'suppliers' && (
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-950/80 text-slate-400 text-[11px] uppercase tracking-wider border-b border-slate-800">
              <tr>
                <th className="py-3 px-4">Supplier ID</th>
                <th className="py-3 px-4">Supplier Name</th>
                <th className="py-3 px-4">Origin Country</th>
                <th className="py-3 px-4">Tier</th>
                <th className="py-3 px-4">Categories</th>
                <th className="py-3 px-4">Reliability</th>
                <th className="py-3 px-4">Direct Contact</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {filteredSuppliers.map((s) => (
                <tr key={s.id} className="hover:bg-slate-800/30 transition-colors">
                  <td className="py-3 px-4 font-mono font-bold text-indigo-300">{s.id}</td>
                  <td className="py-3 px-4">
                    <span className="font-semibold text-white block">{s.name}</span>
                    <span className="text-[10px] text-slate-500 font-mono">{s.code}</span>
                  </td>
                  <td className="py-3 px-4 text-slate-200">{s.country}</td>
                  <td className="py-3 px-4">
                    <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-slate-800 text-slate-300 border border-slate-700">
                      {s.tier}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-slate-400">
                    {s.categories.join(', ')}
                  </td>
                  <td className="py-3 px-4 font-mono font-bold text-emerald-400">
                    {s.reliabilityScore}%
                  </td>
                  <td className="py-3 px-4 font-mono text-[11px] text-slate-400">
                    {s.contactEmail}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* 2. Shipments Table */}
      {activeTab === 'shipments' && (
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-950/80 text-slate-400 text-[11px] uppercase tracking-wider border-b border-slate-800">
              <tr>
                <th className="py-3 px-4">Shipment ID</th>
                <th className="py-3 px-4">Supplier</th>
                <th className="py-3 px-4">SKU / Product</th>
                <th className="py-3 px-4">Quantity</th>
                <th className="py-3 px-4">Mode</th>
                <th className="py-3 px-4">Departure</th>
                <th className="py-3 px-4">Current Scheduled ETA</th>
                <th className="py-3 px-4">Destination Hub</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {filteredShipments.map((shp) => (
                <tr key={shp.id} className="hover:bg-slate-800/30 transition-colors">
                  <td className="py-3 px-4 font-mono font-bold text-indigo-300">
                    {shp.id}
                    <span className="block text-[10px] text-slate-500 font-normal">{shp.trackingNumber}</span>
                  </td>
                  <td className="py-3 px-4 text-slate-200 font-medium">{shp.supplierName}</td>
                  <td className="py-3 px-4">
                    <span className="font-semibold text-white block">{shp.sku}</span>
                    <span className="text-[11px] text-slate-400 block truncate max-w-xs">{shp.productName}</span>
                  </td>
                  <td className="py-3 px-4 font-mono text-slate-200">{shp.quantity.toLocaleString()}</td>
                  <td className="py-3 px-4">
                    <span className="px-2 py-0.5 rounded text-[10px] font-medium bg-slate-800 text-slate-300 border border-slate-700">
                      {shp.transitMode}
                    </span>
                  </td>
                  <td className="py-3 px-4 font-mono text-slate-400">{formatDateDisplay(shp.departureDate)}</td>
                  <td className="py-3 px-4 font-mono font-bold text-cyan-300">{formatDateDisplay(shp.originalEta)}</td>
                  <td className="py-3 px-4 text-[11px] text-slate-400 truncate max-w-xs">{shp.destinationWarehouse}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* 3. Warehouse Stock Table */}
      {activeTab === 'inventory' && (
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-950/80 text-slate-400 text-[11px] uppercase tracking-wider border-b border-slate-800">
              <tr>
                <th className="py-3 px-4">SKU</th>
                <th className="py-3 px-4">Product Name</th>
                <th className="py-3 px-4">Category</th>
                <th className="py-3 px-4">On Hand</th>
                <th className="py-3 px-4">Reserved</th>
                <th className="py-3 px-4">Available Buffer</th>
                <th className="py-3 px-4">Safety Stock Min</th>
                <th className="py-3 px-4">Warehouse Location</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {filteredStock.map((w) => (
                <tr key={w.sku} className="hover:bg-slate-800/30 transition-colors">
                  <td className="py-3 px-4 font-mono font-bold text-indigo-300">{w.sku}</td>
                  <td className="py-3 px-4 font-medium text-white">{w.productName}</td>
                  <td className="py-3 px-4 text-slate-400">{w.category}</td>
                  <td className="py-3 px-4 font-mono text-slate-200">{w.onHand}</td>
                  <td className="py-3 px-4 font-mono text-slate-400">{w.reserved}</td>
                  <td className="py-3 px-4 font-mono font-bold text-emerald-400">{w.available}</td>
                  <td className="py-3 px-4 font-mono text-amber-300">{w.safetyStockThreshold}</td>
                  <td className="py-3 px-4 text-slate-400">{w.warehouseLocation}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* 4. Customer Orders Table */}
      {activeTab === 'orders' && (
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-950/80 text-slate-400 text-[11px] uppercase tracking-wider border-b border-slate-800">
              <tr>
                <th className="py-3 px-4">Order ID</th>
                <th className="py-3 px-4">Customer Account</th>
                <th className="py-3 px-4">Account Tier</th>
                <th className="py-3 px-4">Ordered SKU</th>
                <th className="py-3 px-4">Quantity</th>
                <th className="py-3 px-4">Allocated Shipment</th>
                <th className="py-3 px-4">Contractual Deadline</th>
                <th className="py-3 px-4">SLA Penalty / Day</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {filteredOrders.map((ord) => (
                <tr key={ord.id} className="hover:bg-slate-800/30 transition-colors">
                  <td className="py-3 px-4 font-mono font-bold text-indigo-300">{ord.id}</td>
                  <td className="py-3 px-4 font-semibold text-white">{ord.customerName}</td>
                  <td className="py-3 px-4">
                    <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-slate-800 text-slate-300 border border-slate-700">
                      {ord.customerTier}
                    </span>
                  </td>
                  <td className="py-3 px-4 font-mono text-slate-200">{ord.sku}</td>
                  <td className="py-3 px-4 font-mono text-slate-200">{ord.orderedQuantity.toLocaleString()}</td>
                  <td className="py-3 px-4 font-mono text-indigo-400">{ord.allocatedShipmentId}</td>
                  <td className="py-3 px-4 font-mono font-bold text-amber-300">{formatDateDisplay(ord.deadline)}</td>
                  <td className="py-3 px-4 font-mono text-rose-400 font-semibold">
                    ${ord.slaPenaltyPerDay?.toLocaleString() || '1,000'}/day
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};
