import {
  Supplier,
  Shipment,
  WarehouseStock,
  CustomerOrder,
  SampleNotice,
} from '../types';

export const INITIAL_SUPPLIERS: Supplier[] = [
  {
    id: 'SUP-101',
    name: 'Apex Microelectronics',
    code: 'APEX-TW',
    contactEmail: 'logistics@apex-micro.tw',
    country: 'Taiwan',
    tier: 'Strategic',
    categories: ['Microcontrollers', 'Automotive ICs', 'Semiconductors'],
    reliabilityScore: 94,
  },
  {
    id: 'SUP-102',
    name: 'Pacific Precision Optics',
    code: 'PPO-JP',
    contactEmail: 'shipping@pacific-optics.co.jp',
    country: 'Japan',
    tier: 'Strategic',
    categories: ['Optical Sensors', 'Lenses', 'Industrial Cameras'],
    reliabilityScore: 98,
  },
  {
    id: 'SUP-103',
    name: 'Vanguard Power Systems',
    code: 'VPS-KR',
    contactEmail: 'fulfillment@vanguard-power.kr',
    country: 'South Korea',
    tier: 'Preferred',
    categories: ['Power Inverters', 'Battery Modules', 'Transformers'],
    reliabilityScore: 89,
  },
  {
    id: 'SUP-104',
    name: 'Shenzhen Dynalink Electronics',
    code: 'DYNA-CN',
    contactEmail: 'export@dynalink-sz.com',
    country: 'China',
    tier: 'Preferred',
    categories: ['RF Modules', 'WiFi / BLE Chipsets', 'Antennas'],
    reliabilityScore: 91,
  },
  {
    id: 'SUP-105',
    name: 'Delta Wire & Harness Co.',
    code: 'DELTA-VN',
    contactEmail: 'dispatch@deltawire.vn',
    country: 'Vietnam',
    tier: 'Secondary',
    categories: ['Wiring Harnesses', 'High-Speed Bus Cables'],
    reliabilityScore: 92,
  },
  {
    id: 'SUP-106',
    name: 'Nordic Timber AB',
    code: 'NT-SE',
    contactEmail: 'supply@nordictimber.se',
    country: 'Sweden',
    tier: 'Secondary',
    categories: ['Packaging Crates', 'Wood Pallets', 'Lumber'],
    reliabilityScore: 96,
  },
];

export const INITIAL_SHIPMENTS: Shipment[] = [
  {
    id: 'SHP-8821',
    supplierId: 'SUP-101',
    supplierName: 'Apex Microelectronics',
    trackingNumber: 'OCN-TW-992144',
    sku: 'MCU-X200',
    productName: 'Ultra-Low-Power 32-bit Microcontroller',
    quantity: 1200,
    transitMode: 'Ocean',
    originPort: 'Port of Taichung, Taiwan',
    destinationWarehouse: 'West Coast Dist. Center (Oakland, CA)',
    departureDate: '2026-09-01',
    originalEta: '2026-09-12',
    status: 'In Transit',
  },
  {
    id: 'SHP-8824',
    supplierId: 'SUP-101',
    supplierName: 'Apex Microelectronics',
    trackingNumber: 'AIR-TW-331088',
    sku: 'MCU-X300',
    productName: 'Automotive Safety MCU (ASIL-D Certified)',
    quantity: 850,
    transitMode: 'Air',
    originPort: 'Taoyuan Intl Airport, Taiwan',
    destinationWarehouse: 'Midwest Logistics Hub (Chicago, IL)',
    departureDate: '2026-09-03',
    originalEta: '2026-09-16',
    status: 'In Transit',
  },
  {
    id: 'SHP-7740',
    supplierId: 'SUP-102',
    supplierName: 'Pacific Precision Optics',
    trackingNumber: 'AIR-JP-440212',
    sku: 'SEN-OP40',
    productName: 'Industrial 4K High-Speed Optical Sensor',
    quantity: 450,
    transitMode: 'Air',
    originPort: 'Narita Intl Airport, Japan',
    destinationWarehouse: 'West Coast Dist. Center (Oakland, CA)',
    departureDate: '2026-09-06',
    originalEta: '2026-09-18',
    status: 'In Transit',
  },
  {
    id: 'SHP-7745',
    supplierId: 'SUP-102',
    supplierName: 'Pacific Precision Optics',
    trackingNumber: 'OCN-JP-881920',
    sku: 'SEN-OP60',
    productName: 'Precision Telecentric Inspection Lens',
    quantity: 300,
    transitMode: 'Ocean',
    originPort: 'Port of Yokohama, Japan',
    destinationWarehouse: 'East Coast Center (Newark, NJ)',
    departureDate: '2026-08-28',
    originalEta: '2026-09-22',
    status: 'In Transit',
  },
  {
    id: 'SHP-6612',
    supplierId: 'SUP-103',
    supplierName: 'Vanguard Power Systems',
    trackingNumber: 'OCN-KR-711904',
    sku: 'PWR-MOD80',
    productName: 'Industrial 800W Isolated DC-DC Converter',
    quantity: 600,
    transitMode: 'Ocean',
    originPort: 'Port of Busan, South Korea',
    destinationWarehouse: 'West Coast Dist. Center (Oakland, CA)',
    departureDate: '2026-09-02',
    originalEta: '2026-09-17',
    status: 'In Transit',
  },
  {
    id: 'SHP-5590',
    supplierId: 'SUP-104',
    supplierName: 'Shenzhen Dynalink Electronics',
    trackingNumber: 'AIR-CN-904123',
    sku: 'RF-500',
    productName: 'Sub-GHz Ultra-Long Range Transceiver',
    quantity: 1500,
    transitMode: 'Air',
    originPort: 'Shenzhen Baoan Airport, China',
    destinationWarehouse: 'Midwest Logistics Hub (Chicago, IL)',
    departureDate: '2026-09-04',
    originalEta: '2026-09-14',
    status: 'In Transit',
  },
  {
    id: 'SHP-4401',
    supplierId: 'SUP-105',
    supplierName: 'Delta Wire & Harness Co.',
    trackingNumber: 'OCN-VN-338190',
    sku: 'CBL-HD100',
    productName: 'Heavy-Duty Shielded Mil-Spec Cable Assembly',
    quantity: 2000,
    transitMode: 'Ocean',
    originPort: 'Port of Da Nang, Vietnam',
    destinationWarehouse: 'East Coast Center (Newark, NJ)',
    departureDate: '2026-08-30',
    originalEta: '2026-09-25',
    status: 'In Transit',
  },
];

export const INITIAL_WAREHOUSE_STOCK: WarehouseStock[] = [
  {
    sku: 'MCU-X200',
    productName: 'Ultra-Low-Power 32-bit Microcontroller',
    category: 'Semiconductors',
    onHand: 150,
    reserved: 120,
    available: 30,
    safetyStockThreshold: 200,
    warehouseLocation: 'Oakland Hub - Bay A-14',
  },
  {
    sku: 'MCU-X300',
    productName: 'Automotive Safety MCU (ASIL-D Certified)',
    category: 'Semiconductors',
    onHand: 60,
    reserved: 50,
    available: 10,
    safetyStockThreshold: 150,
    warehouseLocation: 'Chicago Hub - Bay C-02',
  },
  {
    sku: 'SEN-OP40',
    productName: 'Industrial 4K High-Speed Optical Sensor',
    category: 'Sensors',
    onHand: 210,
    reserved: 180,
    available: 30,
    safetyStockThreshold: 100,
    warehouseLocation: 'Oakland Hub - Bay B-08',
  },
  {
    sku: 'SEN-OP60',
    productName: 'Precision Telecentric Inspection Lens',
    category: 'Optics',
    onHand: 80,
    reserved: 40,
    available: 40,
    safetyStockThreshold: 50,
    warehouseLocation: 'Newark Hub - Bay D-11',
  },
  {
    sku: 'PWR-MOD80',
    productName: 'Industrial 800W Isolated DC-DC Converter',
    category: 'Power Systems',
    onHand: 120,
    reserved: 90,
    available: 30,
    safetyStockThreshold: 80,
    warehouseLocation: 'Oakland Hub - Bay A-09',
  },
  {
    sku: 'RF-500',
    productName: 'Sub-GHz Ultra-Long Range Transceiver',
    category: 'RF Modules',
    onHand: 500,
    reserved: 350,
    available: 150,
    safetyStockThreshold: 300,
    warehouseLocation: 'Chicago Hub - Bay C-18',
  },
  {
    sku: 'CBL-HD100',
    productName: 'Heavy-Duty Shielded Mil-Spec Cable Assembly',
    category: 'Cabling',
    onHand: 800,
    reserved: 600,
    available: 200,
    safetyStockThreshold: 400,
    warehouseLocation: 'Newark Hub - Bay E-04',
  },
];

export const INITIAL_CUSTOMER_ORDERS: CustomerOrder[] = [
  {
    id: 'ORD-9014',
    customerName: 'Tesla Mobility Corp',
    customerTier: 'Tier 1 Strategic',
    sku: 'MCU-X200',
    productName: 'Ultra-Low-Power 32-bit Microcontroller',
    orderedQuantity: 500,
    orderDate: '2026-08-25',
    deadline: '2026-09-15',
    allocatedShipmentId: 'SHP-8821',
    status: 'Pending Receipt',
    slaPenaltyPerDay: 1500,
  },
  {
    id: 'ORD-9018',
    customerName: 'Bosch Autonomous Systems',
    customerTier: 'Tier 1 Strategic',
    sku: 'MCU-X300',
    productName: 'Automotive Safety MCU (ASIL-D Certified)',
    orderedQuantity: 400,
    orderDate: '2026-08-27',
    deadline: '2026-09-20',
    allocatedShipmentId: 'SHP-8824',
    status: 'Pending Receipt',
    slaPenaltyPerDay: 2000,
  },
  {
    id: 'ORD-9022',
    customerName: 'Siemens Smart Factory Solutions',
    customerTier: 'Enterprise',
    sku: 'MCU-X200',
    productName: 'Ultra-Low-Power 32-bit Microcontroller',
    orderedQuantity: 300,
    orderDate: '2026-08-28',
    deadline: '2026-09-28',
    allocatedShipmentId: 'SHP-8821',
    status: 'Pending Receipt',
    slaPenaltyPerDay: 800,
  },
  {
    id: 'ORD-9028',
    customerName: 'Raytheon Defense Technologies',
    customerTier: 'Tier 1 Strategic',
    sku: 'MCU-X300',
    productName: 'Automotive Safety MCU (ASIL-D Certified)',
    orderedQuantity: 250,
    orderDate: '2026-08-29',
    deadline: '2026-09-22',
    allocatedShipmentId: 'SHP-8824',
    status: 'Pending Receipt',
    slaPenaltyPerDay: 2500,
  },
  {
    id: 'ORD-9030',
    customerName: 'Rockwell Automation Global',
    customerTier: 'Enterprise',
    sku: 'MCU-X200',
    productName: 'Ultra-Low-Power 32-bit Microcontroller',
    orderedQuantity: 200,
    orderDate: '2026-08-30',
    deadline: '2026-10-15',
    allocatedShipmentId: 'SHP-8821',
    status: 'Pending Receipt',
    slaPenaltyPerDay: 500,
  },
  {
    id: 'ORD-9045',
    customerName: 'GE Healthcare Diagnostic Imaging',
    customerTier: 'Tier 1 Strategic',
    sku: 'SEN-OP40',
    productName: 'Industrial 4K High-Speed Optical Sensor',
    orderedQuantity: 250,
    orderDate: '2026-08-31',
    deadline: '2026-09-24',
    allocatedShipmentId: 'SHP-7740',
    status: 'Pending Receipt',
    slaPenaltyPerDay: 1800,
  },
  {
    id: 'ORD-9052',
    customerName: 'Honeywell Aerospace',
    customerTier: 'Tier 1 Strategic',
    sku: 'PWR-MOD80',
    productName: 'Industrial 800W Isolated DC-DC Converter',
    orderedQuantity: 350,
    orderDate: '2026-09-01',
    deadline: '2026-09-25',
    allocatedShipmentId: 'SHP-6612',
    status: 'Pending Receipt',
    slaPenaltyPerDay: 1200,
  },
  {
    id: 'ORD-9060',
    customerName: 'ABB Robotics Division',
    customerTier: 'Enterprise',
    sku: 'RF-500',
    productName: 'Sub-GHz Ultra-Long Range Transceiver',
    orderedQuantity: 600,
    orderDate: '2026-09-02',
    deadline: '2026-09-21',
    allocatedShipmentId: 'SHP-5590',
    status: 'Pending Receipt',
    slaPenaltyPerDay: 600,
  },
];

export const SAMPLE_NOTICES: SampleNotice[] = [
  {
    id: 'notice-1',
    title: 'Major Supplier Equipment Breakdown',
    category: 'direct_impact',
    badge: 'High Impact Disruption',
    description: 'Critical equipment failure at Apex Microelectronics causing 14-day delay on microcontrollers.',
    content: `FROM: operational-alerts@apex-micro.tw
DATE: September 05, 2026 08:30 GMT+8
SUBJECT: [URGENT NOTICE] Unscheduled Fab Line Interruption - Taichung Cleanroom 4

Dear Global Supply Chain Partner,

We regret to inform you that Apex Microelectronics experienced a catastrophic photolithography cooling chamber failure at our Taichung primary fab facility on September 4, 2026.

As a safety protocol, production across Fab Line 4 (handling our MCU-X200 32-bit controllers and MCU-X300 automotive ASIL-D series) has been halted immediately. Replacement components have been sourced from ASML, but repair, recalibration, and cleanroom qualification will require a total downtime of 14 calendar days.

IMPACT ASSESSMENT:
- Disrupted Supplier: Apex Microelectronics (Taichung Facility)
- Products Affected: MCU-X200, MCU-X300 microcontrollers
- Duration: Estimated 14 days delay across all pending departures and current line dispatches
- Affected Transit Routes: All ocean and air shipments scheduled between Sept 1 and Sept 18, 2026

We deeply apologize for this unforeseen operational disruption. Our technical teams are working around the clock to minimize overall delay. Revised bill of lading and tracking telemetry will follow.

Sincerely,
Chen Wei-Lun
VP of Global Operations, Apex Microelectronics Corp.`,
  },
  {
    id: 'notice-2',
    title: 'Ambiguous Regional Shipping Advisory',
    category: 'ambiguous',
    badge: 'Ambiguous Advisory',
    description: 'Weather advisory with vague timelines and broad East Asian logistics delays.',
    content: `FROM: advisories@pacific-maritime-bulletin.org
DATE: September 05, 2026 06:15 UTC
SUBJECT: Severe Weather Advisory: Super Typhoon 'Kagami' Approaching Western Pacific Shipping Lanes

MARITIME SAFETY & PORT CONGESTION BULLETIN:

Meteorological agencies report Super Typhoon 'Kagami' intensifying to Category 4 as it tracks northwest through the Luzon Strait and Taiwan Strait. 

Port authorities in Kaohsiung, Taichung, and Yokohama have initiated precautionary berth evacuations. Container terminals are expected to operate under severe wind restrictions starting tonight.

SUMMARY OF POTENTIAL IMPACT:
- Region: East Asian shipping corridors (Taiwan, Southern Japan, East China Sea)
- Estimated Transit Delays: Projected 3 to 6 days across general commercial ocean carriers
- Affected Carriers & Suppliers: Unconfirmed. Various regional shippers including Pacific Precision Optics and local feeder lines may see terminal holds
- Key Dates: Port closures expected Sept 6 - Sept 9; terminal congestion clearing through mid-September

Carriers are advised to seek sheltered anchorages. Concrete impact on individual bills of lading remains subject to harbor master clearances post-storm.`,
  },
  {
    id: 'notice-3',
    title: 'Supplier Incident with No Order Impact',
    category: 'no_impact',
    badge: 'No Order Impact',
    description: 'Disruption at Nordic Timber AB (packaging/wood) with zero exposure to active electronic customer orders.',
    content: `FROM: notices@nordictimber.se
DATE: September 05, 2026 11:20 CEST
SUBJECT: Facility Production Halt - Umeå Lumber & Pallet Mill

To All Commercial Accounts,

Please be advised that Nordic Timber AB has encountered an electrical substation transformer fire at our secondary wood-pulp processing and shipping pallet manufacturing mill in Umeå, Sweden on September 4th.

Due to damage to power grid connections, structural timber milling and pallet assembly lines will remain offline for approximately 10 days while municipal energy crews replace high-voltage switchgear.

AFFECTED DETAILS:
- Supplier: Nordic Timber AB
- Product Lines: Standard Euro-pallets (EPAL-1), untreated pine lumber framing, industrial timber crates
- Delay Duration: 10 days
- Resumption Date: Expected September 15, 2026

No electronics, semiconductor subcomponents, or high-tech equipment were stored on premises.

Regards,
Henrik Lindqvist
Plant Manager, Nordic Timber AB`,
  },
  {
    id: 'notice-4',
    title: 'Power Grid Outage at Battery/Power Plant',
    category: 'moderate_impact',
    badge: 'Moderate Impact',
    description: 'Incheon municipal grid brownouts delaying Vanguard Power Systems shipments by 5 days.',
    content: `FROM: supply-coordination@vanguard-power.kr
DATE: September 05, 2026 14:00 KST
SUBJECT: Production Dispatch Delay: Incheon Power Station Grid Maintenance

Attention Procurement & Logistics:

Vanguard Power Systems was notified by KEPCO of emergency substation upgrades following rolling brownouts across the Incheon Industrial Complex.

Testing procedures on our industrial DC-DC converter line (PWR-MOD80 series) require uninterrupted 72-hour burn-in cycles, which cannot proceed safely during grid instability.

OPERATIONAL IMPACT:
- Supplier: Vanguard Power Systems (Incheon, South Korea)
- Products: PWR-MOD80 industrial power conversion modules
- Delay Duration: 5 business days
- Impact Start: September 5, 2026
- Target Shipment Dispatch: September 10, 2026

We anticipate ocean transit SHP-6612 to be delayed accordingly upon departure. Please coordinate with regional logistics handlers.

Best regards,
Min-Jun Park
Director of Logistics, Vanguard Power Systems`,
  },
];
