# Python Flask Backend - Disruption Response Assistant

This folder provides a complete Python Flask backend for the **Disruption Response Assistant**, as specified in the technical requirements.

## Features
- **Gemini API Integration**: Uses Google's official `google-genai` Python SDK to extract structured entities from unstructured disruption emails, weather bulletins, and port advisories.
- **Supply Chain Matching**: Matches suppliers with `sample_data.json` (or SQLite), identifies related shipments, and finds affected customer orders.
- **Delivery Date & Risk Calculation**: Accurately computes new estimated delivery dates based on delay duration and classifies affected orders into **HIGH RISK**, **MEDIUM RISK**, or **LOW RISK** based on customer delivery deadlines.
- **Executive Mitigation Reports**: Generates action-oriented reports with two response options and one recommended action per order.
- **CORS Enabled**: Configured for seamless communication with the Vite/React frontend.

---

## Local Setup Instructions

### 1. Prerequisites
- Python 3.9+
- Node.js 18+ (for the React frontend)
- A Google Gemini API key from [Google AI Studio](https://aistudio.google.com/)

### 2. Install Python Dependencies
In your terminal, navigate to the `backend_flask` directory and set up a virtual environment:

```bash
cd backend_flask
python -m venv venv

# On macOS/Linux:
source venv/bin/activate

# On Windows:
venv\Scripts\activate

# Install requirements:
pip install -r requirements.txt
```

### 3. Configure Environment Variables
Create a `.env` file in `backend_flask/` (or set environment variables in your terminal):

```env
GEMINI_API_KEY="your-actual-gemini-api-key"
FLASK_PORT=5000
```

### 4. Run the Flask Server
```bash
python app.py
```
The server will boot up at `http://127.0.0.1:5000`.

### 5. Connect the React Frontend
In your React application or in `vite.config.ts`, you can configure the proxy or set the API base URL to `http://localhost:5000`:
```ts
// Example in vite.config.ts:
server: {
  proxy: {
    '/api': 'http://127.0.0.1:5000'
  }
}
```
Then start the React frontend in the root directory:
```bash
npm run dev
```

---

## REST API Reference

| Endpoint | Method | Description |
| :--- | :--- | :--- |
| `/api/health` | `GET` | Health check & database statistics |
| `/api/database` | `GET` | Retrieve suppliers, shipments, inventory stock, and customer orders |
| `/api/analyze` | `POST` | Analyze disruption notice text, match supply chain, and calculate risk |
| `/api/history` | `GET` | Get recent disruption analysis runs |
| `/api/history` | `DELETE` | Clear analysis history |
