"""
Disruption Response Assistant - Python Flask Backend
Provides REST API endpoints for:
- Disruption notice analysis using Google Gemini API
- Supply chain database querying (Suppliers, Shipments, Warehouse Stock, Customer Orders)
- Deterministic delivery date calculation and SLA risk classification
- Executive mitigation report generation
"""

import os
import json
import re
from datetime import datetime, timedelta
from flask import Flask, request, jsonify
from flask_cors import CORS
from dotenv import load_dotenv

load_dotenv()

app = Flask(__name__)
CORS(app)

# Load database from sample_data.json
DATA_FILE = os.path.join(os.path.dirname(__file__), "sample_data.json")

def load_db():
    if os.path.exists(DATA_FILE):
        with open(DATA_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    return {"suppliers": [], "shipments": [], "warehouseStock": [], "customerOrders": []}

DATABASE = load_db()
ANALYSIS_HISTORY = []

# Initialize Gemini Client if available
GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY", "")
ai_client = None

if GEMINI_API_KEY:
    try:
        from google import genai
        ai_client = genai.Client(api_key=GEMINI_API_KEY)
    except Exception as e:
        print(f"Warning: Could not initialize google-genai client: {e}")

def add_days(date_str, days):
    try:
        dt = datetime.strptime(date_str, "%Y-%m-%d")
        new_dt = dt + timedelta(days=days)
        return new_dt.strftime("%Y-%m-%d")
    except Exception:
        return date_str

def days_between(date_a_str, date_b_str):
    try:
        a = datetime.strptime(date_a_str, "%Y-%m-%d")
        b = datetime.strptime(date_b_str, "%Y-%m-%d")
        return (b - a).days
    except Exception:
        return 0

def match_supplier(extracted_name, suppliers):
    if not extracted_name:
        return None
    clean_ext = re.sub(r'[^a-zA-Z0-9]', '', extracted_name).lower()
    for s in suppliers:
        clean_name = re.sub(r'[^a-zA-Z0-9]', '', s["name"]).lower()
        clean_code = re.sub(r'[^a-zA-Z0-9]', '', s["code"]).lower()
        if clean_name in clean_ext or clean_ext in clean_name or clean_code in clean_ext:
            return s
        for token in s["name"].lower().split():
            if len(token) > 3 and token in clean_ext:
                return s
    return None

def heuristic_extract(notice_text):
    lower = notice_text.lower()
    matched_supplier = ""
    for s in DATABASE.get("suppliers", []):
        if s["name"].lower() in lower or s["code"].lower() in lower:
            matched_supplier = s["name"]
            break
    if not matched_supplier:
        if "apex" in lower:
            matched_supplier = "Apex Microelectronics"
        elif "pacific precision" in lower or "pacific optics" in lower:
            matched_supplier = "Pacific Precision Optics"
        elif "vanguard" in lower:
            matched_supplier = "Vanguard Power Systems"
        elif "nordic timber" in lower:
            matched_supplier = "Nordic Timber AB"

    delay_days = 7
    m = re.search(r'(\d{1,2})\s*(?:calendar\s*)?(?:business\s*)?days?', lower)
    if m:
        delay_days = int(m.group(1))
    elif "two weeks" in lower:
        delay_days = 14

    disruption_type = "Supply Chain Delay"
    if "breakdown" in lower or "failure" in lower or "equipment" in lower:
        disruption_type = "Equipment Failure & Fab Interruption"
    elif "typhoon" in lower or "weather" in lower or "storm" in lower:
        disruption_type = "Severe Weather & Maritime Port Closure"
    elif "fire" in lower:
        disruption_type = "Facility Fire Incident"
    elif "brownout" in lower or "power" in lower:
        disruption_type = "Electrical Grid Instability"

    return {
        "supplierName": matched_supplier or "Unidentified Supplier",
        "productCategory": "Industrial Components",
        "disruptionType": disruption_type,
        "delayDurationDays": delay_days,
        "importantDates": {
            "incidentDate": "2026-09-04",
            "impactStart": "2026-09-05",
            "estimatedEnd": add_days("2026-09-05", delay_days)
        },
        "rawSummary": f"Notice parsed for {matched_supplier or 'vendor'} reporting {delay_days}-day delay due to {disruption_type}.",
        "confidenceScore": 0.90 if matched_supplier else 0.60,
        "isAmbiguous": "advisory" in lower or "unconfirmed" in lower or "projected" in lower
    }

@app.route("/api/health", methods=["GET"])
def health():
    return jsonify({
        "status": "ok",
        "backend": "Python Flask",
        "geminiConfigured": bool(ai_client),
        "suppliersCount": len(DATABASE.get("suppliers", [])),
        "shipmentsCount": len(DATABASE.get("shipments", [])),
        "ordersCount": len(DATABASE.get("customerOrders", []))
    })

@app.route("/api/database", methods=["GET"])
def get_database():
    return jsonify(DATABASE)

@app.route("/api/history", methods=["GET", "DELETE"])
def history():
    global ANALYSIS_HISTORY
    if request.method == "DELETE":
        ANALYSIS_HISTORY = []
        return jsonify({"message": "History cleared"})
    return jsonify({"history": ANALYSIS_HISTORY})

@app.route("/api/analyze", methods=["POST"])
def analyze():
    data = request.get_json() or {}
    notice_text = data.get("noticeText", "").strip()
    if not notice_text:
        return jsonify({"error": "No notice text provided"}), 400

    extraction = None
    ai_used = False
    gemini_error = None

    if ai_client:
        try:
            prompt = f"""You are a supply chain disruption analyst. Analyze this supplier notice:
---
{notice_text}
---
Extract strict JSON:
supplierName (string), productCategory (string), disruptionType (string),
delayDurationDays (integer), importantDates (object), rawSummary (string),
confidenceScore (float 0.0-1.0), isAmbiguous (boolean).
"""
            response = ai_client.models.generate_content(
                model="gemini-3.8-flash",
                contents=prompt,
                config={
                    "response_mime_type": "application/json"
                }
            )
            parsed = json.loads(response.text)
            extraction = {
                "supplierName": parsed.get("supplierName", "Unidentified Supplier"),
                "productCategory": parsed.get("productCategory", "General Goods"),
                "disruptionType": parsed.get("disruptionType", "Interruption"),
                "delayDurationDays": max(1, int(parsed.get("delayDurationDays", 7))),
                "importantDates": parsed.get("importantDates", {}),
                "rawSummary": parsed.get("rawSummary", "Notice parsed."),
                "confidenceScore": float(parsed.get("confidenceScore", 0.85)),
                "isAmbiguous": bool(parsed.get("isAmbiguous", False))
            }
            ai_used = True
        except Exception as e:
            gemini_error = str(e)
            extraction = heuristic_extract(notice_text)
    else:
        extraction = heuristic_extract(notice_text)
        gemini_error = "GEMINI_API_KEY not configured in Python environment."

    # Supply chain matching
    suppliers = DATABASE.get("suppliers", [])
    shipments = DATABASE.get("shipments", [])
    warehouse_stock = DATABASE.get("warehouseStock", [])
    customer_orders = DATABASE.get("customerOrders", [])

    matched_supplier = match_supplier(extraction["supplierName"], suppliers)

    # Find affected shipments
    affected_shipments = []
    if matched_supplier:
        affected_shipments = [s for s in shipments if s["supplierId"] == matched_supplier["id"]]
    else:
        cat = extraction["productCategory"].lower()
        affected_shipments = [s for s in shipments if cat in s["productName"].lower() or cat in s["sku"].lower()]

    # Match customer orders
    affected_shipment_ids = {s["id"] for s in affected_shipments}
    matched_orders = [o for o in customer_orders if o["allocatedShipmentId"] in affected_shipment_ids]

    # Calculate delivery date and risk
    delay_days = extraction["delayDurationDays"]
    analyzed_orders = []
    for order in matched_orders:
        shp = next((s for s in affected_shipments if s["id"] == order["allocatedShipmentId"]), None)
        orig_eta = shp["originalEta"] if shp else order["deadline"]
        new_eta = add_days(orig_eta, delay_days)
        days_late = days_between(order["deadline"], new_eta)

        if days_late > 0:
            risk = "HIGH"
            reason = f"Arriving {days_late} days past deadline ({order['deadline']}). SLA breach risk."
            opt1 = f"Release emergency safety stock from regional hub to fulfill {order['orderedQuantity']} units."
            opt2 = f"Engage {order['customerName']} to negotiate revised delivery schedule with freight fee credit."
            rec = f"Authorize instant safety stock buffer release to prevent SLA penalty."
        elif days_late >= -3:
            risk = "MEDIUM"
            reason = f"Arriving within {abs(days_late)} days of deadline ({order['deadline']}). Narrow safety buffer."
            opt1 = "Instruct logistics hub to execute same-day priority cross-docking upon arrival."
            opt2 = "Request port carrier priority container offload."
            rec = "Pre-stage express inland transit to compress turnaround time."
        else:
            risk = "LOW"
            reason = f"Safety buffer of {abs(days_late)} days remains before customer deadline ({order['deadline']})."
            opt1 = "Continue standard automated tracking monitoring."
            opt2 = "Log revised ETA in customer enterprise portal."
            rec = f"Update scheduled ETA to {new_eta}. No emergency intervention needed."

        analyzed_orders.append({
            "orderId": order["id"],
            "customerName": order["customerName"],
            "customerTier": order["customerTier"],
            "sku": order["sku"],
            "productName": order["productName"],
            "orderedQuantity": order["orderedQuantity"],
            "allocatedShipmentId": order["allocatedShipmentId"],
            "originalDeliveryDate": orig_eta,
            "newEstimatedDeliveryDate": new_eta,
            "deadline": order["deadline"],
            "delayDays": delay_days,
            "daysLate": days_late,
            "riskLevel": risk,
            "reason": reason,
            "responseOptions": [opt1, opt2],
            "recommendedAction": rec
        })

    has_impact = len(analyzed_orders) > 0
    no_impact_reason = None
    if not has_impact:
        if not matched_supplier:
            no_impact_reason = f"Supplier '{extraction['supplierName']}' does not match any active distributor vendor."
        elif len(affected_shipments) == 0:
            no_impact_reason = f"Supplier '{matched_supplier['name']}' has no active inbound transit shipments."
        else:
            no_impact_reason = f"No open customer orders depend on shipments from '{matched_supplier['name']}'."

    high_c = sum(1 for o in analyzed_orders if o["riskLevel"] == "HIGH")
    med_c = sum(1 for o in analyzed_orders if o["riskLevel"] == "MEDIUM")
    low_c = sum(1 for o in analyzed_orders if o["riskLevel"] == "LOW")

    exec_report = {
        "situationSummary": f"Disruption reported at {matched_supplier['name'] if matched_supplier else extraction['supplierName']} causes {delay_days}-day delay impacting {len(affected_shipments)} shipments and {len(analyzed_orders)} customer orders.",
        "affectedSupplier": matched_supplier["name"] if matched_supplier else extraction["supplierName"],
        "affectedShipments": [s["id"] for s in affected_shipments],
        "affectedCustomerOrders": [o["orderId"] for o in analyzed_orders],
        "riskLevel": "HIGH" if high_c > 0 else ("MEDIUM" if med_c > 0 else "LOW"),
        "riskCounts": {"high": high_c, "medium": med_c, "low": low_c},
        "recommendedAction": "Execute emergency buffer allocation and notify priority tier customers." if high_c > 0 else "Monitor vessel tracking daily.",
        "mitigationStrategy": "1) Allocate local stock buffers.\n2) Expedite in-transit cargo.\n3) Proactively manage customer delivery commitments."
    }

    result = {
        "id": f"res-{int(datetime.utcnow().timestamp()*1000)}",
        "timestamp": datetime.utcnow().isoformat() + "Z",
        "noticeText": notice_text,
        "extraction": extraction,
        "matchedSupplier": matched_supplier,
        "affectedShipments": affected_shipments,
        "affectedOrders": analyzed_orders,
        "executiveReport": exec_report,
        "hasImpact": has_impact,
        "noImpactReason": no_impact_reason
    }

    ANALYSIS_HISTORY.insert(0, result)
    if len(ANALYSIS_HISTORY) > 15:
        ANALYSIS_HISTORY.pop()

    return jsonify({
        "success": True,
        "result": result,
        "aiUsed": ai_used,
        "geminiError": gemini_error
    })

if __name__ == "__main__":
    port = int(os.environ.get("FLASK_PORT", 5000))
    print(f"Flask Supply Chain Backend running on http://127.0.0.1:{port}")
    app.run(host="0.0.0.0", port=port, debug=True)
