import express, { Request, Response } from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI, Type } from '@google/genai';
import {
  INITIAL_SUPPLIERS,
  INITIAL_SHIPMENTS,
  INITIAL_WAREHOUSE_STOCK,
  INITIAL_CUSTOMER_ORDERS,
} from './src/data/sampleDatabase';
import {
  matchSupplier,
  findAffectedShipments,
  matchCustomerOrders,
  analyzeOrderRisks,
  generateExecutiveReport,
  heuristicExtract,
} from './src/utils/analysisEngine';
import { AnalysisResult, AiExtraction } from './src/types';

const app = express();
const PORT = 3000;

app.use(express.json({ limit: '5mb' }));

// In-memory store for recent analyses
const analysisHistory: AnalysisResult[] = [];

// Initialize Gemini Client
const apiKey = process.env.GEMINI_API_KEY || '';
let aiClient: GoogleGenAI | null = null;

if (apiKey) {
  try {
    aiClient = new GoogleGenAI({
      apiKey: apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  } catch (err) {
    console.error('Failed to initialize GoogleGenAI client:', err);
  }
}

// Health Check API
app.get('/api/health', (req: Request, res: Response) => {
  res.json({
    status: 'ok',
    appName: 'Disruption Response Assistant',
    geminiConfigured: !!apiKey,
    model: 'gemini-3.8-flash',
    databaseStats: {
      suppliers: INITIAL_SUPPLIERS.length,
      shipments: INITIAL_SHIPMENTS.length,
      inventorySkus: INITIAL_WAREHOUSE_STOCK.length,
      customerOrders: INITIAL_CUSTOMER_ORDERS.length,
    },
    historyCount: analysisHistory.length,
  });
});

// Get Supply Chain Database
app.get('/api/database', (req: Request, res: Response) => {
  res.json({
    suppliers: INITIAL_SUPPLIERS,
    shipments: INITIAL_SHIPMENTS,
    warehouseStock: INITIAL_WAREHOUSE_STOCK,
    customerOrders: INITIAL_CUSTOMER_ORDERS,
  });
});

// Get Disruption History
app.get('/api/history', (req: Request, res: Response) => {
  res.json({ history: analysisHistory });
});

// Delete Disruption History
app.delete('/api/history', (req: Request, res: Response) => {
  analysisHistory.length = 0;
  res.json({ message: 'History cleared' });
});

// Analyze Disruption Notice API
app.post('/api/analyze', async (req: Request, res: Response) => {
  const { noticeText, forceFallback } = req.body;

  if (!noticeText || typeof noticeText !== 'string' || noticeText.trim().length === 0) {
    return res.status(400).json({ error: 'Please provide a disruption notice text to analyze.' });
  }

  let extraction: AiExtraction;
  let aiUsed = false;
  let geminiError: string | null = null;

  // 1. AI Extraction via Gemini
  if (aiClient && !forceFallback) {
    try {
      const prompt = `You are a supply chain disruption analyst. Analyze this supplier notice, shipping advisory, or incident report:

---
${noticeText}
---

Extract the following in strict JSON format:
1. supplierName: exact supplier or shipping entity name mentioned (or best guess / "Unidentified" if ambiguous)
2. productCategory: affected products, SKUs, or category
3. disruptionType: type of disruption (e.g. "Equipment Failure", "Severe Weather / Typhoon", "Labor Strike", "Facility Fire", "Customs Hold")
4. delayDurationDays: number of delay days (integer). If a range like 3-6 days is given, take the upper realistic estimate (e.g., 5 or 6). If unknown, estimate realistically or use 7.
5. importantDates: { incidentDate: string or null, impactStart: string or null, estimatedEnd: string or null }
6. rawSummary: concise 2-sentence summary of the incident and operational impact
7. confidenceScore: confidence score between 0.0 and 1.0
8. isAmbiguous: boolean indicating whether the advisory is vague, unconfirmed, or regional without specific vessel/order manifests.`;

      const response = await aiClient.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: prompt,
        config: {
          systemInstruction: 'You are an expert supply chain intelligence parser. Output only valid JSON matching the requested schema.',
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              supplierName: { type: Type.STRING },
              productCategory: { type: Type.STRING },
              disruptionType: { type: Type.STRING },
              delayDurationDays: { type: Type.INTEGER },
              importantDates: {
                type: Type.OBJECT,
                properties: {
                  incidentDate: { type: Type.STRING },
                  impactStart: { type: Type.STRING },
                  estimatedEnd: { type: Type.STRING },
                },
              },
              rawSummary: { type: Type.STRING },
              confidenceScore: { type: Type.NUMBER },
              isAmbiguous: { type: Type.BOOLEAN },
            },
            required: ['supplierName', 'disruptionType', 'delayDurationDays', 'rawSummary', 'confidenceScore', 'isAmbiguous'],
          },
        },
      });

      const text = response.text?.trim();
      if (text) {
        const parsed = JSON.parse(text);
        extraction = {
          supplierName: parsed.supplierName || 'Unidentified Supplier',
          productCategory: parsed.productCategory || 'General Goods',
          disruptionType: parsed.disruptionType || 'Supply Chain Interruption',
          delayDurationDays: Math.max(1, Number(parsed.delayDurationDays) || 7),
          importantDates: parsed.importantDates || {},
          rawSummary: parsed.rawSummary || 'Disruption notice parsed.',
          confidenceScore: Number(parsed.confidenceScore) || 0.85,
          isAmbiguous: Boolean(parsed.isAmbiguous),
        };
        aiUsed = true;
      } else {
        throw new Error('Empty response from Gemini API');
      }
    } catch (err: any) {
      console.warn('Gemini extraction failed or timed out:', err?.message || err);
      geminiError = err?.message || 'Gemini API call failed';
      // Graceful fallback to deterministic heuristic parser
      extraction = heuristicExtract(noticeText);
    }
  } else {
    // Fallback heuristic extraction
    extraction = heuristicExtract(noticeText);
    if (!aiClient) {
      geminiError = 'GEMINI_API_KEY is not configured on server. Used heuristic fallback extraction.';
    }
  }

  // 2. Supply Chain Matching
  const matchedSupplier = matchSupplier(extraction.supplierName, INITIAL_SUPPLIERS);
  const affectedShipments = findAffectedShipments(
    matchedSupplier,
    extraction.productCategory,
    INITIAL_SHIPMENTS
  );
  const matchedOrders = matchCustomerOrders(affectedShipments, INITIAL_CUSTOMER_ORDERS);

  // 3. Risk Analysis
  const affectedOrders = analyzeOrderRisks(
    matchedOrders,
    affectedShipments,
    extraction.delayDurationDays,
    INITIAL_WAREHOUSE_STOCK
  );

  // 4. Determine Impact
  const hasImpact = affectedOrders.length > 0;
  let noImpactReason: string | undefined;

  if (!hasImpact) {
    if (!matchedSupplier) {
      noImpactReason = `The supplier "${extraction.supplierName}" was not found in your active vendor network. No related shipments or customer orders are in jeopardy.`;
    } else if (affectedShipments.length === 0) {
      noImpactReason = `Supplier "${matchedSupplier.name}" is verified, but has no active inbound transit shipments or open product lines associated with this event.`;
    } else {
      noImpactReason = `Shipments linked to "${matchedSupplier.name}" were reviewed, but none are currently allocated to pending customer orders. Existing inventory buffers are sufficient.`;
    }
  }

  // 5. Generate AI Executive Report
  let executiveReport = generateExecutiveReport(
    extraction,
    matchedSupplier,
    affectedShipments,
    affectedOrders
  );

  // If Gemini is active and there are affected orders, enrich the executive narrative
  if (aiClient && hasImpact && !forceFallback) {
    try {
      const orderSummaryText = affectedOrders
        .map(
          (o) =>
            `- Order ID: ${o.orderId}, Customer: ${o.customerName} (${o.customerTier}), SKU: ${o.sku}, Qty: ${o.orderedQuantity}, Shipment ID: ${o.allocatedShipmentId}, Deadline: ${o.deadline}, New ETA: ${o.newEstimatedDeliveryDate}, Days Late: ${o.daysLate}, Risk: ${o.riskLevel}`
        )
        .join('\n');

      const reportPrompt = `You are a Chief Supply Chain Officer generating an executive mitigation report for a distributor.
Supplier: ${matchedSupplier?.name}
Disruption: ${extraction.disruptionType} (${extraction.delayDurationDays} days delay)
Shipments: ${affectedShipments.map((s) => s.id).join(', ')}
Affected Customer Orders:
${orderSummaryText}

Generate a JSON object with:
1. situationSummary: a 2-3 sentence executive synopsis highlighting key shipment and customer exposures. Mention specific Shipment IDs and Order IDs.
2. strategicRecommendation: single primary executive action recommended for immediate authorization.
3. mitigationStrategy: 3 concise numbered mitigation steps addressing stock allocation, carrier expedites, and customer SLA communication.`;

      const repRes = await aiClient.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: reportPrompt,
        config: {
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              situationSummary: { type: Type.STRING },
              strategicRecommendation: { type: Type.STRING },
              mitigationStrategy: { type: Type.STRING },
            },
            required: ['situationSummary', 'strategicRecommendation', 'mitigationStrategy'],
          },
        },
      });

      const repText = repRes.text?.trim();
      if (repText) {
        const parsedReport = JSON.parse(repText);
        executiveReport.situationSummary = parsedReport.situationSummary || executiveReport.situationSummary;
        executiveReport.recommendedAction = parsedReport.strategicRecommendation || executiveReport.recommendedAction;
        executiveReport.mitigationStrategy = parsedReport.mitigationStrategy || executiveReport.mitigationStrategy;
      }
    } catch (e) {
      // Keep heuristic report if report enrichment fails
      console.warn('Report enrichment warning:', e);
    }
  }

  const result: AnalysisResult = {
    id: 'res-' + Date.now(),
    timestamp: new Date().toISOString(),
    noticeText,
    extraction,
    matchedSupplier,
    affectedShipments,
    affectedOrders,
    executiveReport,
    hasImpact,
    noImpactReason,
  };

  // Prepend to history (keep latest 15)
  analysisHistory.unshift(result);
  if (analysisHistory.length > 15) {
    analysisHistory.pop();
  }

  return res.json({
    success: true,
    result,
    aiUsed,
    geminiError,
  });
});

// Vite middleware & Static Serving
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Disruption Response Assistant server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Fatal error starting server:', err);
});
